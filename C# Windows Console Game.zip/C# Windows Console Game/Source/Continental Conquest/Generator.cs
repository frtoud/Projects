﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Continental_Conquest
{
    static class Generator
    {
        public const int WIDTH = Interface.WIDTH, HEIGHT = Interface.HEIGHT, MENU_HEIGHT = 8, DEFAULT_AGE = 5;
        static GenTile[,] Map;
        static int[,] Regions;
        static float[,] Magic;
        static int TotalRegions;
        static string[] Names;

        static void Reset()
        {
            TotalRegions = 0;
            Names = new string[1];
            for (int x = 0; x < WIDTH; x++)
            {
                for (int y = 0; y < HEIGHT; y++)
                {
                    Map[x, y] = GenTemplate.Ocean;
                    Regions[x, y] = 0;
                    Magic[x,y] = 0;
                }
            }
        }
        static Generator()
        {
            Map = new GenTile[WIDTH, HEIGHT];
            Regions = new int[WIDTH, HEIGHT];
            Magic = new float[WIDTH, HEIGHT];
            Names = new string[1];
            Reset();
        }

        static public void Run()
        {
            bool end = false;
            Interface.WriteTitle("World Generator");
            Reset();
            while (!end)
            {
                string[] choices;
                int choice;
                if (TotalRegions == 0)
                {
                    choices = new string[2];
                    choices[0] = "New World";
                    choices[1] = "Load World";
                    switch (Interface.Menu(choices, MENU_HEIGHT))
                    {
                        case 0:
                            choice = 1;
                            break;
                        case 1:
                            choice = 3;
                            break;
                        default:
                            choice = -1;
                            break;
                    }
                }
                else
                {
                    choices = new string[4];
                    choices[0] = "Age World";
                    choices[1] = "New World";
                    choices[2] = "Save World";
                    choices[3] = "Load World";
                    choice = Interface.Menu(choices, MENU_HEIGHT);
                }
                switch (choice)
                {
                    case 0:
                        AgeWorld();
                        PrintMap();
                        break;
                    case 1:
                        NewWorld();
                        PrintMap();
                        break;
                    case 2:
                        SaveWorld();
                        break;
                    case 3:
                        LoadWorld();
                        break;
                    default:
                        end = true;
                        break;
                }
            }
            Interface.ClearMap();
            Interface.Clear();
            Interface.ClearLine(1);
        }
        static public void QuickGen(out GenTile[,] map, out float[,] magic, out int[,] regions, out int[][] res, out string[] names)
        {
            NewWorld();
            map = Map;
            magic = Magic;
            regions = Regions;
            res = new int[TotalRegions][];
            names = Names;
            float[][] Ressources = new float[TotalRegions][];
            for (int i = 0; i < TotalRegions; i++)
            {
                res[i] = new int[3];
                Ressources[i] = new float[3];
            }
            for (int y = 0; y < HEIGHT; y++)
            {
                for (int x = 0; x < WIDTH; x++)
                {
                    if (Regions[x, y] != 0)
                    {
                        Ressources[Regions[x, y]][0] += Map[x, y].Wood;
                        Ressources[Regions[x, y]][1] += Map[x, y].Metal;
                        Ressources[Regions[x, y]][2] += Magic[x, y];
                        Ressources[Regions[x, y]][2] = (float)Math.Round(Ressources[Regions[x, y]][2], 1);
                        Ressources[Regions[x, y]][1] = (float)Math.Round(Ressources[Regions[x, y]][1], 1);
                        Ressources[Regions[x, y]][0] = (float)Math.Round(Ressources[Regions[x, y]][0], 1);
                    }
                }
            }
            for (int i = 0; i < TotalRegions; i++)
            {
                res[i][0] = (int)Math.Ceiling(Ressources[i][0]);
                res[i][1] = (int)Math.Ceiling(Ressources[i][1]);
                res[i][2] = (int)Math.Ceiling(Ressources[i][2]);
            }
        }

        static void AgeWorld()
        {
            for (int x = 2; x < WIDTH - 2; x++)
            {
                for (int y = 2; y < HEIGHT - 2; y++)
                {
                    MagicGrowth(Magic, x, y);
                }
            }
            for (int x = 2; x < WIDTH - 2; x++)
            {
                for (int y = 2; y < HEIGHT - 2; y++)
                {
                    if (Map[x, y] != GenTemplate.City)
                    {
                        Map[x, y] = NewTerrain(Map, x, y);
                    }
                }
            }
        }
        static void MagicGrowth(float[,] Magic, int x, int y)
        {
            if (GenTemplate.Random(100) <= 1)
            {
                if (Magic[x, y] < 0.3)
                {
                    for (int X = x - 1; X <= x + 1; X++)
                    {
                        for (int Y = y - 1; Y <= y + 1; Y++)
                        {
                            if (GenTemplate.Random(10) <= 3 && Magic[X, Y] > 0)
                            {
                                Magic[X, Y] -= 0.1f;
                                Magic[x, y] += 0.1f;

                            }
                        }
                    }
                }
                else if (Magic[x, y] < 0.6)
                {
                    int vardX = GenTemplate.Random(-1, 2),
                        vardY = GenTemplate.Random(-1, 2),
                        varoX = GenTemplate.Random(-1, 2),
                        varoY = GenTemplate.Random(-1, 2);

                    if (Magic[x + varoX, y + varoY] > 0 && Magic[x + vardX, y + vardY] < 1.2)
                    {
                        Magic[x + varoX, y + varoY] -= 0.1f ;
                        Magic[x + vardX, y + vardY] += 0.1f ;
                    }
                }
                else
                {
                    for (int X = x - 1; X <= x + 1; X++)
                    {
                        for (int Y = y - 1; Y <= y + 1; Y++)
                        {
                            if (Magic[X, Y] < 1.2 && GenTemplate.Random(10) <= 5)
                            {
                                Magic[X, Y] += 0.1f;
                                Magic[x, y] -= 0.1f;

                            }
                        }
                    }
                }
            }
        }
        static GenTile NewTerrain(GenTile[,] Map, int x, int y)
        {
            const int INERTIA = 300;
            GenTile feature = Map[x, y];
            if (Map[x, y].IsWater)
            {
                int change = 0;
                for (int X = x - 1; X <= x + 1; X++)
                {
                    for (int Y = y - 1; Y <= y + 1; Y++)
                    {
                        if (Map[X, Y].IsWater && Map[X, Y] != Map[x, y])
                        {
                            change++;
                        }
                    }
                }
                if (GenTemplate.Random(INERTIA) < change)
                {
                    if (Map[x, y] == GenTemplate.Ocean)
                    {
                        feature = GenTemplate.Reef;
                    }
                    else
                    {
                        feature = GenTemplate.Ocean;
                    }
                }
            }
            else
            {
                int[] weights = new int[8] { 0, 0, 0, 0, 0, 0, 0, 0 };
                if (Map[x, y] == GenTemplate.Swamp)
                {
                    weights[0] += INERTIA;
                }
                else if (Map[x, y] == GenTemplate.Plains)
                {
                    weights[1] += INERTIA;
                }
                else if (Map[x, y] == GenTemplate.Grassland)
                {
                    weights[2] += INERTIA;
                }
                else if (Map[x, y] == GenTemplate.Forest)
                {
                    weights[3] += INERTIA;
                }
                else if (Map[x, y] == GenTemplate.Hill)
                {
                    weights[4] += INERTIA;
                }
                else if (Map[x, y] == GenTemplate.Mountain)
                {
                    weights[5] += INERTIA;
                }
                else if (Map[x, y] == GenTemplate.Snow)
                {
                    weights[6] += INERTIA;
                }
                else if (Map[x, y] == GenTemplate.Desert)
                {
                    weights[7] += INERTIA;
                }
                weights[6] += (100 / y) - 5;
                for (int X = x - 1; X <= x + 1; X++)
                {
                    for (int Y = y - 1; Y <= y + 1; Y++)
                    {
                        weights[0] += Map[X, Y].ChangeWeights[0];
                        weights[1] += Map[X, Y].ChangeWeights[1];
                        weights[2] += Map[X, Y].ChangeWeights[2];
                        weights[3] += Map[X, Y].ChangeWeights[3];
                        weights[4] += Map[X, Y].ChangeWeights[4];
                        weights[5] += Map[X, Y].ChangeWeights[5];
                        weights[6] += Map[X, Y].ChangeWeights[6];
                        weights[7] += Map[X, Y].ChangeWeights[7];
                    }
                }
                switch (GenTemplate.WeightedRandom(weights))
                {
                    case 1:
                        feature = GenTemplate.Plains;
                        break;
                    case 2:
                        feature = GenTemplate.Grassland;
                        break;
                    case 3:
                        feature = GenTemplate.Forest;
                        break;
                    case 4:
                        feature = GenTemplate.Hill;
                        break;
                    case 5:
                        feature = GenTemplate.Mountain;
                        break;
                    case 6:
                        feature = GenTemplate.Snow;
                        break;
                    case 7:
                        feature = GenTemplate.Desert;
                        break;
                    default:
                        feature = GenTemplate.Swamp;
                        break;
                }
            }
            return feature;
        }

        static void NewWorld()
        {
            Reset();
            ImbueWorld();
            CreateTowns();
            CreateFeatures();
            Names = new string[TotalRegions];
            for (int i = 1; i < TotalRegions; i++)
            {
                Names[i] = GetRegionName(i);
            }
            for (int i = 0; i < DEFAULT_AGE; i++)
            {
                AgeWorld();
            }
        }
        static void CreateTowns()
        {
            const int TOWNMAX = 200;
            int regionNumber = 1;
            for (int x = 0; x < WIDTH; x++)
            {
                for (int y = 0; y < HEIGHT; y++)
                {
                    Map[x, y] = GenTemplate.Ocean;
                    Regions[x, y] = 0;
                }
            }
            for (int i = 0; i < TOWNMAX; i++)
            {
                int x, y, k = 0;
                bool obstructs;
                do
                {
                    k++;
                    x = GenTemplate.Random(5, WIDTH - 5);
                    y = GenTemplate.Random(5, HEIGHT - 5);
                    obstructs = Obstructs(x, y);
                }
                while (obstructs && !(k < TOWNMAX));
                if (!obstructs)
                {
                    for (int X = x - 1; X <= x + 1; X++)
                    {
                        for (int Y = y - 1; Y <= y + 1; Y++)
                        {
                            Map[X, Y] = GenTemplate.Plains;
                            Regions[X, Y] = regionNumber;
                        }
                    }
                    Map[x, y] = GenTemplate.City;
                    for (int X = x - 2; X <= x + 2; X++)
                    {
                        for (int Y = y - 2; Y <= y + 2; Y++)
                        {
                            if (Map[X, Y] == GenTemplate.Ocean && CanConvert(X, Y, 1))
                            {
                                Map[X, Y] = GenTemplate.Plains;
                                Regions[X, Y] = GetRegionNumber(X, Y, regionNumber);
                            }
                        }
                    }
                    for (int X = x - 3; X <= x + 3; X++)
                    {
                        for (int Y = y - 3; Y <= y + 3; Y++)
                        {
                            if (Map[X, Y] == GenTemplate.Ocean && CanConvert(X, Y, 0))
                            {
                                Map[X, Y] = GenTemplate.Plains;
                                Regions[X, Y] = GetRegionNumber(X, Y, regionNumber);
                            }
                        }
                    }
                    for (int X = x - 4; X <= x + 4; X++)
                    {
                        for (int Y = y - 4; Y <= y + 4; Y++)
                        {
                            if (Map[X, Y] == GenTemplate.Ocean && CanConvert(X, Y,  -1))
                            {
                                Map[X, Y] = GenTemplate.Plains;
                                Regions[X, Y] = GetRegionNumber(X, Y, regionNumber);
                            }
                        }
                    }
                    regionNumber++;
                }
            }
            TotalRegions = regionNumber;
        }
        static bool Obstructs(int x, int y)
        {
            bool obstructs = false;
            for (int X = x - 1; !obstructs && X <= x + 1; X++)
            {
                for (int Y = y - 1; !obstructs && Y <= y + 1; Y++)
                {
                    obstructs = obstructs || !Map[X, Y].IsWater;
                }
            }
            return obstructs;
        }
        static int GetRegionNumber(int x, int y, int currentRegion)
        {
            bool isAdjacent = false;
            int result;
            for (int X = x - 1; X <= x + 1 && !isAdjacent; X++)
            {
                for (int Y = y - 1; Y <= y + 1 && !isAdjacent; Y++)
                {
                    if (Regions[X, Y] == currentRegion)
                    {
                        isAdjacent = true;
                    }
                }
            }
            if (isAdjacent)
            {
                result = currentRegion;
            }
            else
            {
                int X, Y, count = 0;
                do
                {
                    X = GenTemplate.Random(x - 1, x + 2);
                    Y = GenTemplate.Random(y - 1, y + 2);
                    count++;
                }
                while (X == x || Y == y || Regions[X,Y] == 0 && count < 100);
                result = Regions[X, Y];
                if (result == 0)
                {
                    result = currentRegion;
                }
            }
            return result;
        }
        static bool CanConvert(int x, int y, int baseChance)
        {
            int chanceToConvert = baseChance;
            for (int X = x - 1; X <= x + 1; X++)
            {
                for (int Y = y - 1; Y <= y + 1; Y++)
                {
                    if (Map[X, Y] != GenTemplate.Ocean)
                    {
                        chanceToConvert++;
                    }
                }
            }
            bool convert = GenTemplate.Random(0, 8) < chanceToConvert;
            return convert;
        }
        static void CreateFeatures()
        {
            const int FEATUREMAX = 500;
            for (int i = 0; i < FEATUREMAX; i++)
            {
                int x, y, k = 0;
                bool obstructs;
                do
                {
                    k++;
                    x = GenTemplate.Random(3, WIDTH - 3);
                    y = GenTemplate.Random(3, HEIGHT - 3);
                    obstructs = Map[x, y] == GenTemplate.City;
                }
                while (obstructs && !(k < FEATUREMAX));
                if (!obstructs)
                {
                    GenTile feature;
                    if (Map[x, y].IsWater)
                    {
                        int r = GenTemplate.Random(0, 8);
                        if (r < 3)
                        {
                            feature = GenTemplate.Reef;
                        }
                        else
                        {
                            feature = GenTemplate.Ocean;
                        }
                    }
                    else
                    {
                        int[] weights = new int[7];
                        weights[0] = GenTemplate.Desert.CreationWeight + (y - HEIGHT) / 8;
                        weights[1] = GenTemplate.Swamp.CreationWeight;
                        weights[2] = GenTemplate.Grassland.CreationWeight;
                        weights[3] = GenTemplate.Forest.CreationWeight;
                        weights[4] = GenTemplate.Hill.CreationWeight;
                        weights[5] = GenTemplate.Mountain.CreationWeight;
                        weights[6] = GenTemplate.Snow.CreationWeight + (HEIGHT - y) / 5;
                        int r = GenTemplate.WeightedRandom(weights);
                        switch (r)
                        {
                            case 1:
                                feature = GenTemplate.Swamp;
                                break;
                            case 2:
                                feature = GenTemplate.Grassland;
                                break;
                            case 3:
                                feature = GenTemplate.Forest;
                                break;
                            case 4:
                                feature = GenTemplate.Hill;
                                break;
                            case 5:
                                feature = GenTemplate.Mountain;
                                break;
                            case 6:
                                feature = GenTemplate.Snow;
                                break;
                            default:
                                feature = GenTemplate.Desert;
                                break;
                        }

                    }

                    for (int X = x - 1; X <= x + 1; X++)
                    {
                        for (int Y = y - 1; Y <= y + 1; Y++)
                        {
                            if (Map[X, Y] != GenTemplate.City && CanExpand(feature, X, Y, 1))
                            {
                                Map[X, Y] = feature;
                            }
                        }
                    }
                    for (int X = x - 2; X <= x + 2; X++)
                    {
                        for (int Y = y - 2; Y <= y + 2; Y++)
                        {
                            if (Map[X, Y] != GenTemplate.City && CanExpand(feature, X, Y, 0))
                            {
                                Map[X, Y] = feature;
                            }
                        }
                    }
                }
            }
        }
        static bool CanExpand(GenTile feature, int x, int y, int baseChance)
        {
            int chanceToConvert = baseChance;
            for (int X = x - 1; X <= x + 1; X++)
            {
                for (int Y = y - 1; Y <= y + 1; Y++)
                {
                    if (Map[X, Y] == feature)
                    {
                        chanceToConvert++;
                    }
                }
            }
            bool convert = GenTemplate.Random(0, 8) < chanceToConvert;
            return convert && feature.IsWater == Map[x, y].IsWater;
        }
        static void ImbueWorld()
        {
            const int MAGICMAX = 120;
            for (int x = 0; x < WIDTH; x++)
            {
                for (int y = 0; y < HEIGHT; y++)
                {
                    Magic[x, y] = 0;
                }
            }
            for (int i = 0; i < MAGICMAX; i++)
            {
                int x = GenTemplate.Random(7, WIDTH - 7);
                int y = GenTemplate.Random(7, HEIGHT - 7);
                Magic[x, y] += 0.2f;
                for (int X = x - 1; X <= x + 1; X++)
                {
                    for (int Y = y - 1; Y <= y + 1; Y++)
                    {
                        if (GenTemplate.Random(0, 8) < 5)
                        {
                            Magic[X, Y] += 0.1f;
                        }
                    }
                }
                for (int X = x - 2; X <= x + 2; X++)
                {
                    for (int Y = y - 2; Y <= y + 2; Y++)
                    {
                        if (GenTemplate.Random(0, 8) < 3)
                        {
                            Magic[X, Y] += 0.1f;
                        }
                    }
                }
            }
        }

        static void SaveWorld()
        {
            Interface.Clear(MENU_HEIGHT);
            Console.SetCursorPosition(WIDTH + 2,MENU_HEIGHT + 2);
            Console.Write("Name:");
            bool cancel = false;
            string name = Interface.GetStringInput(ref cancel);
            if (!cancel)
            {
                float[][] Ressources = new float[TotalRegions][];
                for (int i = 0; i < TotalRegions; i++)
                {
                    Ressources[i] = new float[3] { 0, 0, 0 };
                }
                System.IO.StreamWriter File = new System.IO.StreamWriter(@Interface.MAPFOLDER + "//" + name + Interface.MAPEXT);
                StringBuilder World = new StringBuilder();
                World.AppendLine(String.Format("{0},{1}", name, TotalRegions));
                for (int y = 0; y < HEIGHT; y++)
                {
                    for (int x = 0; x < WIDTH; x++)
                    {
                        char terrain = EncodeTerrain(Map[x, y]);
                        int region = Regions[x, y];
                        int magic = (int)(Magic[x, y] * 10);
                        World.AppendLine(String.Format("{0},{1},{2}", terrain, region, magic));
                        if (Regions[x, y] != 0)
                        {
                            Ressources[region][0] += Map[x, y].Wood;
                            Ressources[region][1] += Map[x, y].Metal;
                            Ressources[region][2] += Magic[x, y];
                            Ressources[region][2] = (float)Math.Round(Ressources[region][2], 1);
                            Ressources[region][1] = (float)Math.Round(Ressources[region][1], 1);
                            Ressources[region][0] = (float)Math.Round(Ressources[region][0], 1);
                        }
                    }
                }
                for (int i = 1; i < TotalRegions; i++)
                {
                    World.AppendLine(String.Format("{0},{1},{2},{3},{4}", i, Names[i], Math.Ceiling(Ressources[i][0]), Math.Ceiling(Ressources[i][1]), Math.Ceiling(Ressources[i][2])));
                }
                File.Write(World);
                File.Flush();
                File.Close();
            }
            Interface.Clear(MENU_HEIGHT);
        }
        static public char EncodeTerrain(GenTile Tile)
        {
            char terrain = ' ';
            if (Tile == GenTemplate.Ocean)
            {
                terrain = 'O';
            }
            else if (Tile == GenTemplate.Reef)
            {
                terrain = 'R';
            }
            else if (Tile == GenTemplate.Swamp)
            {
                terrain = 'S';
            }
            else if (Tile == GenTemplate.Plains)
            {
                terrain = 'P';
            }
            else if (Tile == GenTemplate.Grassland)
            {
                terrain = 'G';
            }
            else if (Tile == GenTemplate.Forest)
            {
                terrain = 'F';
            }
            else if (Tile == GenTemplate.Hill)
            {
                terrain = 'H';
            }
            else if (Tile == GenTemplate.Mountain)
            {
                terrain = 'M';
            }
            else if (Tile == GenTemplate.Snow)
            {
                terrain = 'N';
            }
            else if (Tile == GenTemplate.Desert)
            {
                terrain = 'D';
            }
            else if (Tile == GenTemplate.City)
            {
                terrain = 'C';
            }
            return terrain;
        }
        static string GetRegionName(int regionNo)
        {
            int length = GenTemplate.Random(2, 5);
            string name = "";
            int[] weights = new int[2];
            for (int y = 0; y < HEIGHT; y++)
            {
                for (int x = 0; x < WIDTH; x++)
                {
                    if (Regions[x, y] == regionNo)
                    {
                        if (Map[x, y] == GenTemplate.Swamp)
                        {
                            weights[0]++;
                        }
                        else if (Map[x, y] == GenTemplate.Plains)
                        {
                            weights[1]++;
                        }
                        else if (Map[x, y] == GenTemplate.Grassland)
                        {
                            weights[0]++;
                        }
                        else if (Map[x, y] == GenTemplate.Forest)
                        {
                            weights[0]++;
                        }
                        else if (Map[x, y] == GenTemplate.Hill)
                        {
                            weights[1]++;
                        }
                        else if (Map[x, y] == GenTemplate.Mountain)
                        {
                            weights[1]++;
                        }
                        else if (Map[x, y] == GenTemplate.Snow)
                        {
                            weights[1]++;
                        }
                        else if (Map[x, y] == GenTemplate.Desert)
                        {
                            weights[1]++;
                        }
                        else if (Map[x, y] == GenTemplate.City)
                        {
                            weights[0]++;
                        }
                    }
                }
            }
            for (int i = 0; i < length; i++)
            {
                int x = GenTemplate.WeightedRandom(weights);
                name += GenTemplate.GetSyllable(x);
            }
            return new string((char.ToUpper(name[0]).ToString() + name.Remove(0, 1)).ToCharArray());
        }

        static void LoadWorld()
        {
            string[] maps = System.IO.Directory.EnumerateFiles(@Interface.MAPFOLDER, "*" + Interface.MAPEXT).ToArray<string>();
            for (int i = 0; i < maps.Length; i++)
            {
                maps[i] = maps[i].Substring(5, maps[i].Length - 9);
            }
            int mapIndex = Interface.Menu(maps, MENU_HEIGHT);
            if (mapIndex != -1)
            {
                DecodeMap(maps[mapIndex]);
                PrintMap();
            }
        }
        static void DecodeMap(string fileName)
        {
            Reset();
            System.IO.StreamReader file = new System.IO.StreamReader(@Interface.MAPFOLDER + "\\" + fileName + Interface.MAPEXT);
            string line = file.ReadLine();
            string[] inputs = line.Split(',');
            TotalRegions = int.Parse(inputs[1]);
            Names = new string[TotalRegions];
            for (int y = 0; y < HEIGHT; y++)
            {
                for (int x = 0; x < WIDTH; x++)
                {
                    line = file.ReadLine();
                    inputs = line.Split(',');
                    Map[x, y] = DecodeTerrain(inputs[0][0]);
                    Regions[x, y] = int.Parse(inputs[1]);
                    Magic[x,y] = int.Parse(inputs[2]) * 0.1f;
                }
            }
            for (int i = 1; i < TotalRegions; i++)
            {
                line = file.ReadLine();
                inputs = line.Split(',');
                Names[i] = inputs[1];
            }
            file.Close();
        }
        static GenTile DecodeTerrain(char c)
        {
            GenTile tile = GenTemplate.Ocean;
            switch (c)
            {
                case 'R':
                    tile = GenTemplate.Reef;
                    break;
                case 'S':
                    tile = GenTemplate.Swamp;
                    break;
                case 'P':
                    tile = GenTemplate.Plains;
                    break;
                case 'G':
                    tile = GenTemplate.Grassland;
                    break;
                case 'C':
                    tile = GenTemplate.City;
                    break;
                case 'F':
                    tile = GenTemplate.Forest;
                    break;
                case 'H':
                    tile = GenTemplate.Hill;
                    break;
                case 'M':
                    tile = GenTemplate.Mountain;
                    break;
                case 'D':
                    tile = GenTemplate.Desert;
                    break;
                case 'N':
                    tile = GenTemplate.Snow;
                    break;
                default:
                    break;
            }
            return tile;
        }

        static void PrintMap()
        {
            float wood = 0, metal = 0, magic = 0;
            for (int y = 0; y < HEIGHT; y++)
            {
                Console.SetCursorPosition(0, y);
                for (int x = 0; x < WIDTH; x++)
                {
                    if (Map[x, y].IsWater)
                    {
                        Console.BackgroundColor = ConsoleColor.Blue;
                        Console.ForegroundColor = ConsoleColor.Black;
                    }
                    else
                    {
                        magic += Magic[x, y];
                        wood += Map[x, y].Wood;
                        metal += Map[x, y].Metal;
                        if (Magic[x, y] >= 0.8f)
                        {
                            
                            Console.ForegroundColor = ConsoleColor.DarkRed;
                        }
                        else if (Magic[x, y] >= 0.6f)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                        }
                        else if (Magic[x, y] >= 0.3f)
                        {
                            Console.ForegroundColor = ConsoleColor.Yellow;
                        }
                        else if (Magic[x, y] > 0)
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                        }
                    }
                    Console.Write(Map[x, y].Symbol);
                    Console.ResetColor();
                }
            }
            Interface.ClearLine(4, 6);
            Console.SetCursorPosition(Interface.MENUPOSX + 2, 4);
            Console.Write("Wood: {0}", Math.Round(wood, 1));
            Console.SetCursorPosition(Interface.MENUPOSX + 2, 5);
            Console.Write("Metal: {0}", Math.Round(metal, 1));
            Console.SetCursorPosition(Interface.MENUPOSX + 2, 6);
            Console.Write("Magic: {0}", Math.Round(magic, 1));
        }
    }
    
    class GenTile
    {
        public char Symbol { get; private set; }
        public bool IsWater { get; private set; }
        public int CreationWeight { get; private set; }
        public int[] ChangeWeights { get; private set; }
        public float Wood { get; private set; }
        public float Metal { get; private set; }

        public GenTile(char symbol, bool isWater, int cw, int[] weights, float wood = 0, float metal = 0)
        {
            Symbol = symbol;
            IsWater = isWater;
            CreationWeight = cw;
            ChangeWeights = weights;
            Wood = wood;
            Metal = metal;
        }
    }

    static class GenTemplate
    {
        static Random Gen { get; set; }
        static List<string> RoughSyllables { get; set; }
        static List<string> SoftSyllables { get; set; }
        static public GenTile City { get; private set; }
        static public GenTile Ocean { get; private set; }
        static public GenTile Reef { get; private set; }
        static public GenTile Swamp { get; private set; }
        static public GenTile Desert { get; private set; }
        static public GenTile Plains { get; private set; }
        static public GenTile Grassland { get; private set; }
        static public GenTile Forest { get; private set; }
        static public GenTile Hill { get; private set; }
        static public GenTile Mountain { get; private set; }
        static public GenTile Snow { get; private set; }

        static GenTemplate()
        {
            Gen = new Random();
            TileList();
            Syllables();
        }
        static void TileList()
        {                                                    //  3   3   3   3   3   3   4   4
            City = new GenTile('#', false, 0, new int[8]      {  0,  0,  1,  1,  0,  0,  0,  0 });         //2
            Ocean = new GenTile('▒', true, 0, new int[8]      {  1,  0,  0,  0,  0,  0,  0,  1 });         //2
            Reef = new GenTile('▓', true, 0, new int[8]       {  0,  0,  0,  0,  1,  1,  0,  0 });         //2
            Swamp = new GenTile('▬', false, 1, new int[8]     {  1,  1,  1,  1,  0,  0,  0, -1 });         //3
            Plains = new GenTile('.', false, 0, new int[8]    {  0,  2,  1,  0,  1,  0, -1,  0 });         //3
            Grassland = new GenTile(';', false, 2, new int[8] {  0,  0,  1,  1,  0,  0,  0,  0 }, 0.2f, 0);//2
            Forest = new GenTile('♣', false, 2, new int[8]    {  0,  0,  1,  2,  0, -1,  0,  0 }, 0.4f, 0);//3
            Hill = new GenTile('⌂', false, 2, new int[8]      {  0,  0,  0,  0,  1,  1,  0,  0 }, 0, 0.2f);//2
            Mountain = new GenTile('▲', false, 2, new int[8]  {  0,  0,  0, -1,  1,  2,  1,  0 }, 0, 0.4f);//3
            Snow = new GenTile('*', false, -3, new int[8]     {  0,  0,  0,  0, -1,  0,  3, -1 });         //3
            Desert = new GenTile('=', false, 4, new int[8]    {  0,  0, -1,  0,  0,  0, -1,  3 });         //3
        }                                                    //  S   P   G   F   H   M   N   D
        static void Syllables()
        {
            char[] Vowels = new char[] { 'a', 'e', 'i', 'y' };
            char[] RoughVowels = new char[] { 'o', 'u' };
            char[] Consonants = new char[] { 'b', 'c', 'f', 'g', 'h', 'j', 'l', 'm', 'n', 'p', 's', 'v', 'w', 'z' };
            char[] RoughConsonants = new char[] { 'd', 'k', 'q', 'r', 't', 'x'};
            SoftSyllables = new List<string>(1000);
            RoughSyllables = new List<string>(1000);
            for (int l1 = 0; l1 < Consonants.Length; l1++)
            {
                for (int l2 = 0; l2 < Vowels.Length; l2++)
                {
                    for (int l3 = 0; l3 < RoughConsonants.Length; l3++)
                    {
                        RoughSyllables.Add(String.Format("{0}{1}{2}",Consonants[l1],Vowels[l2],RoughConsonants[l3]));
                    }
                    for (int l3 = 0; l3 < Consonants.Length; l3++)
                    {
                        SoftSyllables.Add(String.Format("{0}{1}{2}", Consonants[l1], Vowels[l2], Consonants[l3]));
                    }
                    for (int l3 = 0; l3 < Vowels.Length; l3++)
                    {
                        SoftSyllables.Add(String.Format("{0}{1}{2}", Consonants[l1], Vowels[l2], Vowels[l3]));
                    }
                    for (int l3 = 0; l3 < RoughVowels.Length; l3++)
                    {
                        SoftSyllables.Add(String.Format("{0}{1}{2}", Consonants[l1], Vowels[l2], RoughVowels[l3]));
                    }
                }
                for (int l2 = 0; l2 < RoughVowels.Length; l2++)
                {
                    for (int l3 = 0; l3 < RoughConsonants.Length; l3++)
                    {
                        RoughSyllables.Add(String.Format("{0}{1}{2}", Consonants[l1], RoughVowels[l2], RoughConsonants[l3]));
                    }
                    for (int l3 = 0; l3 < Consonants.Length; l3++)
                    {
                        SoftSyllables.Add(String.Format("{0}{1}{2}", Consonants[l1], RoughVowels[l2], Consonants[l3]));
                    }
                    for (int l3 = 0; l3 < Vowels.Length; l3++)
                    {
                        SoftSyllables.Add(String.Format("{0}{1}{2}", Consonants[l1], RoughVowels[l2], Vowels[l3]));
                    }
                    for (int l3 = 0; l3 < RoughVowels.Length; l3++)
                    {
                        RoughSyllables.Add(String.Format("{0}{1}{2}", Consonants[l1], RoughVowels[l2], RoughVowels[l3]));
                    }
                }
            }
            for (int l1 = 0; l1 < RoughConsonants.Length; l1++)
            {
                for (int l2 = 0; l2 < Vowels.Length; l2++)
                {
                    for (int l3 = 0; l3 < RoughConsonants.Length; l3++)
                    {
                        RoughSyllables.Add(String.Format("{0}{1}{2}", RoughConsonants[l1], Vowels[l2], RoughConsonants[l3]));
                    }
                    for (int l3 = 0; l3 < Consonants.Length; l3++)
                    {
                        RoughSyllables.Add(String.Format("{0}{1}{2}", RoughConsonants[l1], Vowels[l2], Consonants[l3]));
                    }
                    for (int l3 = 0; l3 < Vowels.Length; l3++)
                    {
                        RoughSyllables.Add(String.Format("{0}{1}{2}", RoughConsonants[l1], Vowels[l2], Vowels[l3]));
                    }
                    for (int l3 = 0; l3 < RoughVowels.Length; l3++)
                    {
                        RoughSyllables.Add(String.Format("{0}{1}{2}", RoughConsonants[l1], Vowels[l2], RoughVowels[l3]));
                    }
                }
                for (int l2 = 0; l2 < RoughVowels.Length; l2++)
                {
                    for (int l3 = 0; l3 < RoughConsonants.Length; l3++)
                    {
                        RoughSyllables.Add(String.Format("{0}{1}{2}", RoughConsonants[l1], RoughVowels[l2], RoughConsonants[l3]));
                    }
                    for (int l3 = 0; l3 < Consonants.Length; l3++)
                    {
                        RoughSyllables.Add(String.Format("{0}{1}{2}", RoughConsonants[l1], RoughVowels[l2], Consonants[l3]));
                    }
                    for (int l3 = 0; l3 < Vowels.Length; l3++)
                    {
                        RoughSyllables.Add(String.Format("{0}{1}{2}", RoughConsonants[l1], RoughVowels[l2], Vowels[l3]));
                    }
                    for (int l3 = 0; l3 < RoughVowels.Length; l3++)
                    {
                        RoughSyllables.Add(String.Format("{0}{1}{2}", RoughConsonants[l1], RoughVowels[l2], RoughVowels[l3]));
                    }
                }
            }
            for (int l1 = 0; l1 < Vowels.Length; l1++)
            {
                for (int l2 = 0; l2 < RoughConsonants.Length; l2++)
                {
                    RoughSyllables.Add(String.Format("{0}{1}", Vowels[l1], RoughConsonants[l2]));
                }
                for (int l2 = 0; l2 < Consonants.Length; l2++)
                {
                    SoftSyllables.Add(String.Format("{0}{1}", Vowels[l1], Consonants[l2]));
                }
            }
            for (int l1 = 0; l1 < RoughVowels.Length; l1++)
            {
                for (int l2 = 0; l2 < RoughConsonants.Length; l2++)
                {
                    RoughSyllables.Add(String.Format("{0}{1}", RoughVowels[l1], RoughConsonants[l2]));
                }
                for (int l2 = 0; l2 < Consonants.Length; l2++)
                {
                    RoughSyllables.Add(String.Format("{0}{1}", RoughVowels[l1], Consonants[l2]));
                }
            }
        }

        static public int Random()
        {
            return Gen.Next(100);
        }
        static public int Random(int max)
        {
            return Gen.Next(max);
        }
        static public int Random(int min, int max)
        {
            return Gen.Next(min, max);
        }
        static public int WeightedRandom(int[] Weights)
        {
            int[] weightlist = new int[Weights.Length];
            for (int i = 0; i < Weights.Length; i++)
            {
                if (Weights[i] < 0)
                {
                    Weights[i] = 0;
                }
                weightlist[i] = Weights[i];
                if (i > 0)
                {
                    weightlist[i] += weightlist[i - 1];
                }
            }
            int r = Random(0, weightlist[weightlist.Length - 1]);
            int x;
            bool found = false;
            for (x = 0; !found && x < weightlist.Length; x++)
            {
                found = weightlist[x] > r;
            }
            return x-1;
        }
        static public string GetSyllable(int param)
        {
            List<string> bank;
            switch (param)
            {
                case 1:
                    bank = RoughSyllables;
                    break;
                default:
                    bank = SoftSyllables;
                    break;
            }
            return bank[Random(bank.Count)];
        }
    }
}
