﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Continental_Conquest
{
    static class Game
    {
        public const int HEIGHT = Interface.HEIGHT, WIDTH = Interface.WIDTH, MENUHEIGHT = 8;
        static string mapName;
        static int currentPlayer;
        static MapTile[,] Map;
        static Region[] Regions;
        static PlayerInfo[] Players;
        static bool Win;

        static Game()
        {
            Map = new MapTile[WIDTH, HEIGHT];
            Players = new PlayerInfo[6];
            Reset();
        }
        static void Reset()
        {
            Win = false;
            for (int x = 0; x < WIDTH; x++)
            {
                for (int y = 0; y < HEIGHT; y++)
                {
                    Map[x, y] = new MapTile(Template.Ocean, 0, 0);
                }
            }
            Region[] Regions = new Region[0];
            currentPlayer = 0;
            Players[0] = new PlayerInfo(0, ConsoleColor.White, ConsoleColor.Black);
            Players[1] = new PlayerInfo(1, ConsoleColor.Red, ConsoleColor.DarkRed);
            Players[2] = new PlayerInfo(2, ConsoleColor.Cyan, ConsoleColor.DarkCyan);
            Players[3] = new PlayerInfo(3, ConsoleColor.Green, ConsoleColor.DarkGreen);
            Players[4] = new PlayerInfo(4, ConsoleColor.Yellow, ConsoleColor.DarkYellow);
            Players[5] = new PlayerInfo(5, ConsoleColor.Magenta, ConsoleColor.DarkMagenta);
        }

        static public void Run()
        {
            Interface.WriteTitle("New Game");
            string[] options = new string[2] { "Load Map", "Quick Play" };
            Reset();
            bool OK = false;
            switch (Interface.Menu(options, MENUHEIGHT))
            {
                case 0:
                    OK = LoadMap();
                    break;
                case 1:
                    OK = QuickPlay();
                    break;
            }
            if (OK)
            {
                ReadPlayers();
                PrintMap();
                currentPlayer = 1;
                Play();
            }
        }
        static public void Load()
        {
            Reset();
            string[] saves = System.IO.Directory.EnumerateFiles(@Interface.SAVEFOLDER, "*" + Interface.SAVEXT).ToArray<string>();
            for (int i = 0; i < saves.Length; i++)
            {
                saves[i] = saves[i].Substring(6, saves[i].Length - 10);
            }
            int mapIndex = Interface.Menu(saves, MENUHEIGHT);
            if (mapIndex >= 0)
            {
                DecodeSave(saves[mapIndex]);
                PrintMap();
                Play();
            }
        }
        static void DecodeSave(string fileName)
        {
            System.IO.StreamReader file = new System.IO.StreamReader(@Interface.SAVEFOLDER + "\\" + fileName + Interface.SAVEXT);
            string line = file.ReadLine();
            string[] inputs = line.Split(',');
            mapName = inputs[0];
            currentPlayer = int.Parse(inputs[2]);
            Regions = new Region[int.Parse(inputs[1])];
            Regions[0] = Template.Sea;
            for (int p = 1; p < Players.Length; p++ )
            {
                line = file.ReadLine();
                inputs = line.Split(',');
                if (int.Parse(inputs[2]) == 1)
                {
                    Players[p].Activate(inputs[1], int.Parse(inputs[3]), int.Parse(inputs[4]), int.Parse(inputs[5]));
                }
            }
            for (int y = 0; y < HEIGHT; y++)
            {
                for (int x = 0; x < WIDTH; x++)
                {
                    line = file.ReadLine();
                    inputs = line.Split(',');
                    Tile tile = DecodeTile(inputs[0][0]);
                    if (inputs.Length == 3)
                    {
                        Map[x, y] = new MapTile(tile, int.Parse(inputs[1]), int.Parse(inputs[2]));
                    }
                    else if (inputs.Length == 4)
                    {
                        Map[x, y] = new MapTile(tile, int.Parse(inputs[1]), int.Parse(inputs[2]), new Unit(Template.City, int.Parse(inputs[3])));
                    }
                    else
                    {
                        Map[x,y] = new MapTile(tile,
                            int.Parse(inputs[1]),
                            int.Parse(inputs[2]),
                            new Unit(Template.Units(int.Parse(inputs[4])),
                                int.Parse(inputs[3]),
                                int.Parse(inputs[5]),
                                int.Parse(inputs[6]),
                                int.Parse(inputs[7]),
                                int.Parse(inputs[8]),
                                int.Parse(inputs[9]),
                                int.Parse(inputs[10])));
                    }
                }
            }
            for (int r = 1; r < Regions.Length; r++)
            {
                line = file.ReadLine();
                inputs = line.Split(',');
                Regions[r] = new Region(inputs[1],
                    new int[] { int.Parse(inputs[2]), int.Parse(inputs[3]), int.Parse(inputs[4]) });
                Regions[r].ChangePlayer(int.Parse(inputs[5]));
            }
            file.Close();
            do
            {
                currentPlayer++;
                if (currentPlayer >= Players.Length)
                {
                    currentPlayer = 1;
                }
            }
            while (!Players[currentPlayer].IsActive);
        }

        static bool LoadMap()
        {
            string[] maps = System.IO.Directory.EnumerateFiles(@Interface.MAPFOLDER, "*" + Interface.MAPEXT).ToArray<string>();
            for (int i = 0; i < maps.Length; i++)
            {
                maps[i] = maps[i].Substring(5, maps[i].Length - 9);
            }
            int mapIndex = Interface.Menu(maps, MENUHEIGHT);
            if (mapIndex >= 0)
            {
                DecodeMap(maps[mapIndex]);
                return true;
            }
            else
            {
                return false;
            }
        }
        static void DecodeMap(string fileName)
        {
            System.IO.StreamReader file = new System.IO.StreamReader(@Interface.MAPFOLDER + "\\" + fileName + Interface.MAPEXT);
            string line = file.ReadLine();
            string[] inputs = line.Split(',');
            mapName = inputs[0];
            Regions = new Region[int.Parse(inputs[1])];
            Regions[0] = Template.Sea;
            for (int y = 0; y < HEIGHT; y++)
            {
                for (int x = 0; x < WIDTH; x++)
                {
                    line = file.ReadLine();
                    inputs = line.Split(',');
                    Tile t = DecodeTile(inputs[0][0]);
                    if (t == null)
                    {
                        Map[x, y] = new MapTile(Template.Grassland, int.Parse(inputs[1]), int.Parse(inputs[2]), new Unit(Template.City, 0));
                    }
                    else
                    {
                        Map[x, y] = new MapTile(t, int.Parse(inputs[1]), int.Parse(inputs[2]));
                    }
                }
            }
            for (int i = 1; i < Regions.Length; i++)
            {
                line = file.ReadLine();
                inputs = line.Split(',');
                Regions[i] = new Region(inputs[1], new int[]{int.Parse(inputs[2]),int.Parse(inputs[3]),int.Parse(inputs[4])});
            }
            file.Close();
        }
        static Tile DecodeTile(char c)
        {
            Tile tile = Template.Ocean;
            switch (c)
            {
                case 'R':
                    tile = Template.Reef;
                    break;
                case 'S':
                    tile = Template.Swamp;
                    break;
                case 'P':
                    tile = Template.Plains;
                    break;
                case 'G':
                    tile = Template.Grassland;
                    break;
                case 'C':
                    tile = null;
                    break;
                case 'F':
                    tile = Template.Forest;
                    break;
                case 'H':
                    tile = Template.Hill;
                    break;
                case 'M':
                    tile = Template.Mountain;
                    break;
                case 'N':
                    tile = Template.Snow;
                    break;
                case 'D':
                    tile = Template.Desert;
                    break;
            }
            return tile;
        }
        static bool QuickPlay()
        {
            GenTile[,] map;
            float[,] magic;
            int[,] regions;
            int[][] ressources;
            string[] names;
            Generator.QuickGen(out map, out magic, out regions, out ressources, out names);
            for (int x = 0; x < WIDTH; x++)
            {
                for (int y = 0; y < HEIGHT; y++)
                {
                    Tile t = DecodeTile(Generator.EncodeTerrain(map[x, y]));
                    if (t == null)
                    {
                        Map[x, y] = new MapTile(Template.Grassland, regions[x, y],(int)(magic[x,y]*10), new Unit(Template.City, 0));
                    }
                    else
                    {
                        Map[x, y] = new MapTile(t, regions[x, y], (int)(magic[x,y]*10));
                    }
                }
            }
            Regions = new Region[names.Length];
            Regions[0] = Template.Sea;
            for (int i = 1; i < Regions.Length; i++)
            {
                Regions[i] = new Region(names[i], ressources[i]);
            }
            mapName = "";
            return true;
        }

        static void ReadPlayers()
        {
            bool cancel = false;
            bool[] taken = new bool[Regions.Length];
            taken[0] = true;
            for (int i = 1; i < taken.Length; i++)
            {
                taken[i] = false;
            }
            for (int p = 1; p < Players.Length && !cancel; p++)
            {
                Interface.Clear(MENUHEIGHT);
                Console.SetCursorPosition(66, MENUHEIGHT + 1);
                Console.ForegroundColor = Players[p].UnitColor;
                Console.Write("Player {0}", p);
                Console.ResetColor();
                Console.SetCursorPosition(66, MENUHEIGHT + 2);
                Console.Write("Name:");
                string name = Interface.GetStringInput(ref cancel);
                if (cancel && p < 3)
                {
                    cancel = false;
                    name = string.Format("Player{0}", p);
                }
                if (!cancel)
                {
                    Players[p].Activate(name);
                    int region, X = 0, Y = 0;
                    do
                    {
                        region = Template.Random(1, taken.Length);
                    }
                    while (taken[region]);
                    bool stop = false;
                    for (int x = 0; x < WIDTH && !stop; x++)
                    {
                        for (int y = 0; y < HEIGHT && !stop; y++)
                        {
                            if (Map[x, y].IsCity && Map[x, y].Region == region)
                            {
                                stop = true;
                                X = x;
                                Y = y;
                            }
                        }
                    }
                    const int RANGE = 16;
                    for (int x = 0; x < WIDTH; x++)
                    {
                        for (int y = 0; y < HEIGHT; y++)
                        {
                            if (Math.Sqrt((x-X)*(x-X)+(y-Y)*(y-Y)) <= RANGE && Map[x,y].IsCity)
                            {
                                taken[Map[x, y].Region] = true;
                            }
                        }
                    }
                    Map[X, Y].Unit.ChangeCityOwner(p);
                    Regions[region].ChangePlayer(p);
                }
            }
        }

        static void Play()
        {
            Win = false;
            bool play = true;
            while (play)
            {
                if (PlayerUpdate())
                {
                    bool turn = true;
                    while (turn && !Win)
                    {
                        Interface.Clear();
                        Console.ForegroundColor = Players[currentPlayer].UnitColor;
                        Interface.WriteTitle(Players[currentPlayer].Name + "'s Turn");
                        Console.ResetColor();
                        string[] options = new string[6];
                        options[0] = "Inspect";
                        options[1] = "Move Unit";
                        options[2] = "Create Unit";
                        options[3] = "Status";
                        options[4] = "Next Turn";
                        options[5] = "Save";
                        switch (Interface.Menu(options, MENUHEIGHT, "Exit"))
                        {
                            case 0:
                                Inspect();
                                break;
                            case 1:
                                Move();
                                break;
                            case 2:
                                Create();
                                break;
                            case 3:
                                Status();
                                break;
                            case 4:
                                turn = false;
                                break;
                            case 5:
                                play = Save();
                                turn = play;
                                break;
                            case -2:
                                goto case 4;
                            default:
                                turn = false;
                                play = false;
                                break;
                        }
                    }
                }
                else
                {
                    Players[currentPlayer].Deactivate();
                }
                if (Win)
                {
                    play = false;
                }
                else
                {
                    do
                    {
                        currentPlayer++;
                        if (currentPlayer >= Players.Length)
                        {
                            currentPlayer = 1;
                        }
                    }
                    while (!Players[currentPlayer].IsActive);
                }
            }
            if (Win)
            {

            }
            Interface.ClearMap();
            Interface.Clear();
        }
        
        static bool PlayerUpdate()
        {
            const int MINIMUM = 3;
            bool active = false;
            int[] total = new int[3] { 0, 0, 0 };
            int[] avail = new int[3] { Players[currentPlayer].GetAvailiable(0), Players[currentPlayer].GetAvailiable(1), Players[currentPlayer].GetAvailiable(2) };
            for (int r = 1; r < Regions.Length; r++)
            {
                if (Regions[r].Player == currentPlayer)
                {
                    total[0] += Regions[r][0];
                    total[1] += Regions[r][1];
                    total[2] += Regions[r][2];
                    active = true;
                    int[] weights = new int[3] { Regions[r][0], Regions[r][1], Regions[r][2]};
                    int resIndex = GenTemplate.WeightedRandom(weights);
                    avail[resIndex]++;
                }
            }
            for (int i = 0; i < 3; i++)
            {
                if (total[i] < MINIMUM)
                {
                    total[i] = MINIMUM;
                }
                if (avail[i] > total[i])
                {
                    avail[i] = total[i];
                }
            }
            if (avail[0] == 0 && avail[1] == 0 && avail[2] == 0)
            {
                avail[Template.Random(3)]++;
            }
            for (int x = 0; x < WIDTH; x++)
            {
                for (int y = 0; y < HEIGHT; y++)
                {
                    if (Map[x, y].IsAlive && Map[x, y].Unit.Player == currentPlayer)
                    {
                        Map[x, y].Unit.SetMovement();
                        if (UnitHealCheck(x, y))
                        {
                            active = true;
                        }
                    }
                    else if (Map[x, y].IsCity && Map[x, y].Unit.Player == currentPlayer)
                    {
                        Map[x, y].Unit.SetMovement();
                    }
                    else if (Map[x, y].IsAlive || Map[x, y].IsCity)
                    {
                        Map[x, y].Unit.ResetMovement();
                    }
                }
            }
            Players[currentPlayer].UpdateRessources(total, avail);
            return active;
        }
        static bool UnitHealCheck(int X,int Y)
        {
            const int FORTIFY_HEAL = -2,
                       REGION_HEAL = -1;
                       //DECAY = 3;
            if (Map[X, Y].Unit.IsFortified)
            {
                Map[X, Y].Unit.RemoveHP(FORTIFY_HEAL);
                if (Regions[Map[X, Y].Region].Player == currentPlayer)
                {
                    Map[X, Y].Unit.RemoveHP(REGION_HEAL);
                }
            }
            return Map[X, Y].IsAlive;
        }

        static void CheckWin()
        {
            int p = 0;
            bool stop = false;
            for (int x = 0; x < WIDTH && !stop; x++)
            {
                for (int y = 0; y < HEIGHT && !stop; y++)
                {
                    if ((Map[x, y].IsAlive || Map[x,y].IsCity) && p == 0)
                    {
                        p = Map[x, y].Unit.Player;
                    }
                    else if ((Map[x, y].IsAlive || Map[x,y].IsCity) && p != Map[x, y].Unit.Player && !(Map[x,y].Unit.Player == 0))
                    {
                        stop = true;
                    }
                }
            }
            if (!stop)
            {
                currentPlayer = p;
                Win = true;
            }
        }

        static void Inspect()
        {
            Interface.Clear();
            Console.SetCursorPosition(Interface.MENUPOSX + 5, MENUHEIGHT - 2);
            Console.Write("Inspect Map");
            bool end = false;
            int cursorX = 32, cursorY = 26;
            while (!end)
            {
                PrintCursor(cursorX, cursorY);
                Interface.Clear(MENUHEIGHT);
                PrintDescription(cursorX, cursorY);
                int prevX = cursorX, prevY = cursorY;
                bool valid = false;
                while (!valid)
                {
                    ConsoleKeyInfo key = Console.ReadKey(true);
                    switch (key.Key)
                    {
                        case ConsoleKey.Escape:
                            end = true;
                            valid = true;
                            break;
                        case ConsoleKey.UpArrow:
                            if (cursorY > 0)
                            {
                                --cursorY;
                                valid = true;
                            }
                            break;
                        case ConsoleKey.DownArrow:
                            if (cursorY < HEIGHT - 1)
                            {
                                ++cursorY;
                                valid = true;
                            }
                            break;
                        case ConsoleKey.LeftArrow:
                            if (cursorX > 0)
                            {
                                --cursorX;
                                valid = true;
                            }
                            break;
                        case ConsoleKey.RightArrow:
                            if (cursorX < WIDTH - 1)
                            {
                                ++cursorX;
                                valid = true;
                            }
                            break;
                        default:
                            break;
                    }
                }
                PrintMap(prevX, prevY);
            }
        }
        static void PrintDescription(int x, int y)
        {
            string magic = "None";
            string player;
            if (Map[x, y].Magic > 6)
            {
                magic = "High";
            }
            else if (Map[x, y].Magic > 2)
            {
                magic = "Medium";
            }
            else if (Map[x, y].Magic > 0)
            {
                magic = "Low";
            }
            if (Regions[Map[x, y].Region].Player == 0)
            {
                player = "None";
            }
            else if (Regions[Map[x, y].Region].Player == currentPlayer)
            {
                player = "You";
            }
            else
            {
                player = Players[Regions[Map[x, y].Region].Player].Name;
            }
            Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT);
            Console.Write("Terrain: {0} Magic: {1}", Map[x,y].Tile.Name.PadRight(9), magic);
            if (Map[x, y].Region != 0)
            {
                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 2);
                if (Map[x, y].IsCity)
                {
                    Console.Write("City of {0}", Regions[Map[x,y].Region].Name);
                }
                else
                {
                    Console.Write("Region of {0}", Regions[Map[x, y].Region].Name);
                }
                Console.SetCursorPosition(Interface.MENUPOSX + 2, MENUHEIGHT + 3);
                Console.Write("Wood:{0}  Metal:{1}  Magic:{2}", Regions[Map[x, y].Region][0].ToString().PadLeft(2), Regions[Map[x, y].Region][1].ToString().PadLeft(2), Regions[Map[x, y].Region][2].ToString().PadLeft(2));
                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 4);
                Console.Write("Owner: ");
                Console.ForegroundColor = Players[Regions[Map[x,y].Region].Player].UnitColor;
                Console.Write(player);
                Console.ResetColor();
            }
            if (Map[x, y].IsAlive)
            {
                if (Map[x, y].Unit.Player == currentPlayer)
                {
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 6);
                    Console.Write("Friendly ");
                    Console.ForegroundColor = Players[Map[x, y].Unit.Player].UnitColor;
                    Console.Write(Map[x, y].Unit.Class.Name.PadRight(12));
                    Console.ResetColor();
                    if (Map[x, y].Unit.IsFortified)
                    {
                        Console.Write(" (F)");
                    }
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 7);
                    Console.Write("{0}/{1}HP Atk:{2} Def:{3} Mov:{4}", Map[x, y].Unit.HP.ToString().PadLeft(3), Map[x, y].Unit.MaxHP.ToString().PadRight(3), Map[x, y].Unit.Attack.ToString().PadLeft(3), Map[x, y].Unit.Defense.ToString().PadLeft(3), Math.Round(Map[x, y].Unit.Movement,2));
                }
                else
                {
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 6);
                    Console.Write("Ennemy ");
                    Console.ForegroundColor = Players[Map[x, y].Unit.Player].UnitColor;
                    Console.Write(Map[x, y].Unit.Class.Name);
                    Console.ResetColor();
                    if (Map[x,y].Unit.HP < Map[x, y].Unit.MaxHP/2)
                    {
                        Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 7);
                        Console.Write("(Wounded)");
                    }
                }
            }
        }

        static void Move()
        {
            Interface.Clear();
            Console.SetCursorPosition(Interface.MENUPOSX + 5, MENUHEIGHT);
            Console.Write("Move Unit");
            bool end = false;
            while (!end && !Win)
            {
                Interface.Clear(MENUHEIGHT + 1);
                List<string> units = new List<string>();
                List<int[]> positions = new List<int[]>();
                for (int y = 0; y < HEIGHT; y++)
                {
                    for (int x = 0; x < WIDTH; x++)
                    {
                        if (Map[x, y].IsAlive && Map[x, y].Unit.Player == currentPlayer && Map[x, y].Unit.Movement > 0)
                        {
                            string F = "";
                            if (Map[x,y].Unit.IsFortified)
                            {
                                F = "[F]";
                            }
                            units.Add(String.Format("{0} {1}/{2}HP {3}", Map[x, y].Unit.Class.Name.PadRight(12), Map[x, y].Unit.HP.ToString().PadLeft(3), Map[x, y].Unit.MaxHP.ToString().PadRight(3), F));
                            positions.Add(new int[2] { x, y });
                        }
                    }
                }
                if (units.Count != 0)
                {
                    string[] choices = units.ToArray<string>();
                    int[][] pos = positions.ToArray<int[]>();
                    int[] choice = CursorMenu(choices, pos, MENUHEIGHT + 2);
                    if (choice[0] < 0)
                    {
                        end = true;
                    }
                    else
                    {
                        MoveUnit(choice[0], choice[1]);
                    }
                }
                else
                {
                    end = true;
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 2);
                    Console.Write("No Moveable Units.");
                    Console.ReadKey(true);
                }
            }
        }
        static void MoveUnit(int X, int Y)
        {
            bool end = false;
            while (!end)
            {
                Interface.Clear(MENUHEIGHT + 1);
                Console.SetCursorPosition(Interface.MENUPOSX, MENUHEIGHT + 2);
                Console.Write("Movement Left: {0}", Map[X, Y].Unit.Movement);
                int choice = MovementWheel(X, Y);
                if (choice > 0)
                {
                    if (choice == 5)
                    {
                        Map[X, Y].Unit.ResetMovement();
                        Map[X, Y].Unit.Fortify();
                        PrintMap(X, Y);
                    }
                    else
                    {
                        int dX, dY;
                        GetDeltas(choice, out dX, out dY);
                        if (Map[X + dX, Y + dY].IsAlive)
                        {
                            Map[X, Y].Unit.ResetMovement();
                            Map[X, Y].Unit.Unfortify();
                            PrintMap(X, Y);
                            MeleeCombat(X, Y, X + dX, Y + dY);
                            if (!Map[X + dX, Y + dY].IsAlive)
                            {
                                Map[X + dX, Y + dY].AddUnit(Map[X, Y].Unit);
                                Map[X, Y].KillUnit();
                                PrintMap(X, Y);
                                X += dX;
                                Y += dY;
                                PrintMap(X, Y);
                            }
                            else
                            {
                                PrintMap(X, Y);
                                PrintMap(X + dX, Y + dY);
                            }
                        }
                        else if (Map[X + dX, Y + dY].IsCity)
                        {
                            Map[X, Y].Unit.ResetMovement();
                            Map[X + dX, Y + dY].Unit.ChangeCityOwner(currentPlayer);
                            Regions[Map[X + dX, Y + dY].Region].ChangePlayer(currentPlayer);
                            PrintMap(Map[X + dX, Y + dY].Region);
                            CheckWin();
                            Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                            Console.ForegroundColor = Players[currentPlayer].UnitColor;
                            Console.Write("{0} was captured.", Regions[Map[X + dX, Y + dY].Region].Name);
                            if (!Win)
                            {
                                Console.ReadKey(true);
                            }
                            Console.ResetColor();
                        }
                        else
                        {
                            float diagonal = 1f;
                            if (dX != 0 && dY != 0)
                            {
                                diagonal = 1.4f;
                            }
                            Map[X + dX, Y + dY].AddUnit(Map[X, Y].Unit);
                            Map[X, Y].KillUnit();
                            PrintMap(X, Y);
                            X += dX;
                            Y += dY;
                            Map[X, Y].Unit.RemoveMovement(Map[X, Y].Tile.MovementCost * diagonal);
                            PrintMap(X, Y);
                        }
                    }
                }
                else
                {
                    if (choice == -1)
                    {
                        end = SpecialCombat(X, Y);
                        if (end)
                        {
                            Map[X, Y].Unit.ResetMovement();
                        }
                    }
                    else if (choice == 0)
                    {
                        end = true;
                    }
                }
                if (!Map[X, Y].IsAlive)
                {
                    end = true;
                }
                else if (Map[X, Y].Unit.Movement < 0.15f)
                {
                    Map[X, Y].Unit.ResetMovement();
                    end = true;
                }
            }
        }

        static int MovementWheel(int X, int Y, bool create = false)
        {
            int choice = 0;
            Interface.Clear(MENUHEIGHT + 4);
            int[] evaluations = EvaluateMovement(X, Y);
            ConsoleColor[] color = new ConsoleColor[10];
            for (int i = 0; i <= 9; i++)
            {
                ConsoleColor c;
                switch (evaluations[i])
                {
                    case 1:
                        c = ConsoleColor.Red;
                        break;
                    case 2:
                        c = ConsoleColor.DarkGreen;
                        break;
                    case 3:
                        c = ConsoleColor.Black;
                        break;
                    case 4:
                        if (create) { c = ConsoleColor.Black; }
                        else { c = ConsoleColor.DarkBlue; }
                        break;
                    default:
                        c = ConsoleColor.White;
                        break;
                }
                color[i] = c;
            }
            PrintWheel(color);
            bool spec = false;
            if (Map[X, Y].Unit.Class is SpecialUnit)
            {
                foreach (SpecialUnit u in new List<UnitClass>() { Map[X, Y].Unit.Class })
                {
                    Console.SetCursorPosition(Interface.MENUPOSX + 8, MENUHEIGHT + 6);
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write("  S: {0}", u.Special);
                    spec = true;
                }
            }
            Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
            bool valid = false;
            while (!valid)
            {
                ConsoleKeyInfo key = Console.ReadKey(true);
                Interface.ClearLine(MENUHEIGHT + 10);
                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                int i;
                switch (key.Key)
                {
                    case ConsoleKey.UpArrow:
                        goto case ConsoleKey.NumPad8;
                    case ConsoleKey.S:
                        if (!create && spec)
                        {
                            choice = -1;
                            valid = true;
                        }
                        break;
                    case ConsoleKey.RightArrow:
                        goto case ConsoleKey.NumPad6;
                    case ConsoleKey.LeftArrow:
                        goto case ConsoleKey.NumPad4;
                    case ConsoleKey.DownArrow:
                        goto case ConsoleKey.NumPad2;
                    case ConsoleKey.Escape:
                        goto case ConsoleKey.NumPad0;
                    case ConsoleKey.D0:
                        goto case ConsoleKey.NumPad0;
                    case ConsoleKey.D1:
                        goto case ConsoleKey.NumPad1;
                    case ConsoleKey.D2:
                        goto case ConsoleKey.NumPad2;
                    case ConsoleKey.D3:
                        goto case ConsoleKey.NumPad3;
                    case ConsoleKey.D4:
                        goto case ConsoleKey.NumPad4;
                    case ConsoleKey.D5:
                        goto case ConsoleKey.NumPad5;
                    case ConsoleKey.D6:
                        goto case ConsoleKey.NumPad6;
                    case ConsoleKey.D7:
                        goto case ConsoleKey.NumPad7;
                    case ConsoleKey.D8:
                        goto case ConsoleKey.NumPad8;
                    case ConsoleKey.D9:
                        goto case ConsoleKey.NumPad9;
                    case ConsoleKey.NumPad0:
                        valid = true;
                        choice = 0;
                        break;
                    case ConsoleKey.NumPad1:
                        i = 1;
                        switch (evaluations[i])
                        {
                            case 1:
                                if (create)
                                {
                                    Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.Write("Ennemy unit in the way.");
                                }
                                else
                                {
                                    goto default;
                                }
                                break;
                            case 2:
                                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("Friendly unit in the way.");
                                break;
                            case 3:
                                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("Impossible movement.");
                                break;
                            default:
                                valid = true;
                                choice = i;
                                break;
                        }
                        break;
                    case ConsoleKey.NumPad2:
                        i = 2;
                        switch (evaluations[i])
                        {
                            case 1:
                                if (create)
                                {
                                    Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.Write("Ennemy unit in the way.");
                                }
                                else
                                {
                                    goto default;
                                }
                                break;
                            case 2:
                                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("Friendly unit in the way.");
                                break;
                            case 3:
                                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("Impossible movement.");
                                break;
                            default:
                                valid = true;
                                choice = i;
                                break;
                        }
                        break;
                    case ConsoleKey.NumPad3:
                        i = 3;
                        switch (evaluations[i])
                        {
                            case 1:
                                if (create)
                                {
                                    Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.Write("Ennemy unit in the way.");
                                }
                                else
                                {
                                    goto default;
                                }
                                break;
                            case 2:
                                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("Friendly unit in the way.");
                                break;
                            case 3:
                                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("Impossible movement.");
                                break;
                            default:
                                valid = true;
                                choice = i;
                                break;
                        }
                        break;
                    case ConsoleKey.NumPad4:
                        i = 4;
                        switch (evaluations[i])
                        {
                            case 1:
                                if (create)
                                {
                                    Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.Write("Ennemy unit in the way.");
                                }
                                else
                                {
                                    goto default;
                                }
                                break;
                            case 2:
                                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("Friendly unit in the way.");
                                break;
                            case 3:
                                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("Impossible movement.");
                                break;
                            default:
                                valid = true;
                                choice = i;
                                break;
                        }
                        break;
                    case ConsoleKey.NumPad5:
                        if (evaluations[5] == 0)
                        {
                            valid = true;
                            choice = 5;
                        }
                        else
                        {
                            if (create)
                            {
                                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("Cannot create unit on city.");
                            }
                            else
                            {
                                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("Cannot fortify on water.");
                            }
                        }
                        break;
                    case ConsoleKey.NumPad6:
                        i = 6;
                        switch (evaluations[i])
                        {
                            case 1:
                                if (create)
                                {
                                    Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.Write("Ennemy unit in the way.");
                                }
                                else
                                {
                                    goto default;
                                }
                                break;
                            case 2:
                                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("Friendly unit in the way.");
                                break;
                            case 3:
                                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("Impossible movement.");
                                break;
                            default:
                                valid = true;
                                choice = i;
                                break;
                        }
                        break;
                    case ConsoleKey.NumPad7:
                        i = 7;
                        switch (evaluations[i])
                        {
                            case 1:
                                if (create)
                                {
                                    Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.Write("Ennemy unit in the way.");
                                }
                                else
                                {
                                    goto default;
                                }
                                break;
                            case 2:
                                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("Friendly unit in the way.");
                                break;
                            case 3:
                                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("Impossible movement.");
                                break;
                            default:
                                valid = true;
                                choice = i;
                                break;
                        }
                        break;
                    case ConsoleKey.NumPad8:
                        i = 8;
                        switch (evaluations[i])
                        {
                            case 1:
                                if (create)
                                {
                                    Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.Write("Ennemy unit in the way.");
                                }
                                else
                                {
                                    goto default;
                                }
                                break;
                            case 2:
                                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("Friendly unit in the way.");
                                break;
                            case 3:
                                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("Impossible movement.");
                                break;
                            default:
                                valid = true;
                                choice = i;
                                break;
                        }
                        break;
                    case ConsoleKey.NumPad9:
                        i = 9;
                        switch (evaluations[i])
                        {
                            case 1:
                                if (create)
                                {
                                    Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.Write("Ennemy unit in the way.");
                                }
                                else
                                {
                                    goto default;
                                }
                                break;
                            case 2:
                                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("Friendly unit in the way.");
                                break;
                            case 3:
                                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 10);
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("Impossible movement.");
                                break;
                            default:
                                valid = true;
                                choice = i;
                                break;
                        }
                        break;
                }
            }
            Console.ResetColor();
            return choice;
        }
        static int[] EvaluateMovement(int X, int Y)
        {
            int[] result = new int[10];
            if (Map[X, Y].IsAlive && Map[X, Y].Unit.Class is Tree)
            {
                result = new int[] {3,3,3,3,3,3,3,3,3,3};
            }
            else
            {
                int index = 1;
                for (int y = Y + 1; y >= Y - 1; y--)
                {
                    for (int x = X - 1; x <= X + 1; x++)
                    {
                        if (x < 0 || y < 0 || x >= WIDTH || y >= HEIGHT)
                        {
                            result[index] = 3;
                        }
                        else if (x == X && y == Y)
                        {
                            if (Map[x, y].Tile == Template.Ocean || Map[x, y].IsCity)
                            {
                                result[index] = 4;
                            }
                            else
                            {
                                result[index] = 0;
                            }
                        }
                        else
                        {
                            if (Map[x, y].Tile.MovementCost > 0)
                            {
                                if (Map[x, y].IsCity || Map[x, y].IsAlive)
                                {
                                    if (Map[x, y].Unit.Player == currentPlayer)
                                    {
                                        result[index] = 2;
                                    }
                                    else
                                    {
                                        result[index] = 1;
                                    }
                                }
                                else
                                {
                                    result[index] = 0;
                                }
                            }
                            else
                            {
                                result[index] = 3;
                            }
                        }
                        index++;
                    }
                }
            }
            return result;
        }
        static void PrintWheel(ConsoleColor[] colors)
        {
            Console.SetCursorPosition(Interface.MENUPOSX + 2, MENUHEIGHT + 4);
            Console.ForegroundColor = colors[7];
            Console.Write("7 ");
            Console.ForegroundColor = colors[8];
            Console.Write("8");
            Console.ForegroundColor = colors[9];
            Console.Write(" 9");
            Console.SetCursorPosition(Interface.MENUPOSX + 2, MENUHEIGHT + 5);
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.Write(" \\↑/");
            Console.SetCursorPosition(Interface.MENUPOSX + 2, MENUHEIGHT + 6);
            Console.ForegroundColor = colors[4];
            Console.Write("4");
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.Write("←");
            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = colors[5];
            Console.Write("5");
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Write("→");
            Console.ForegroundColor = colors[6];
            Console.Write("6");
            Console.SetCursorPosition(Interface.MENUPOSX + 2, MENUHEIGHT + 7);
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.Write(" /↓\\");
            Console.SetCursorPosition(Interface.MENUPOSX + 2, MENUHEIGHT + 8);
            Console.ForegroundColor = colors[1];
            Console.Write("1 ");
            Console.ForegroundColor = colors[2];
            Console.Write("2");
            Console.ForegroundColor = colors[3];
            Console.Write(" 3");
            Console.SetCursorPosition(Interface.MENUPOSX + 8, MENUHEIGHT + 4);
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("Esc: Cancel");
        }
        static void GetDeltas(int choice, out int dX, out int dY)
        {
            switch (choice)
            {
                case 1:
                    dX = -1; 
                    dY = 1;
                    break;
                case 2:
                    dX = 0;
                    dY = 1;
                    break;
                case 3:
                    dX = 1;
                    dY = 1;
                    break;
                case 4:
                    dX = -1;
                    dY = 0;
                    break;
                case 6:
                    dX = 1;
                    dY = 0;
                    break;
                case 7:
                    dX = -1;
                    dY = -1;
                    break;
                case 8:
                    dX = 0;
                    dY = -1;
                    break;
                case 9:
                    dX = 1;
                    dY = -1;
                    break;
                default:
                    dX = 0;
                    dY = 0;
                    break;
            }
        }

        static void MeleeCombat(int OffenseX, int OffenseY, int DefenseX, int DefenseY)
        {
            const int BASEHEIGHT = MENUHEIGHT + 10, DMGCAP = 999;
            const float RETALIATE = 2 / 3f;
            int writtenline = 1;
            Interface.Clear(BASEHEIGHT);
            Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT);
            Console.ForegroundColor = ConsoleColor.White;
            MapTile Offense = Map[OffenseX, OffenseY];
            MapTile Defense = Map[DefenseX, DefenseY];
            string OffenseName = Offense.Unit.Class.Name;
            string DefenseName = Defense.Unit.Class.Name;
            UnitClass OffenseClass = Offense.Unit.Class;
            UnitClass DefenseClass = Defense.Unit.Class;
            Console.Write("{0} Attacks!", OffenseName);
            float effectiveness = GetEffectiveness(Offense.Unit.Class.Type, Defense.Unit.Class.Type);
            int CritChance = Offense.Unit.BaseCrit;
            int Krit = 1;
            if (CriticalHit(CritChance))
            {
                System.Threading.Thread.Sleep(1000);
                Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT + writtenline);
                writtenline++;
                Console.ForegroundColor = Players[currentPlayer].UnitColor;
                Console.Write("CRITICAL HIT!!");
                Console.ForegroundColor = ConsoleColor.White;
                Krit = 2;
            }
            int damage = (int)Math.Round(Offense.Attack*effectiveness*Krit - Defense.Defense);
            bool flinched = false;
            if (damage > DMGCAP)
            {
                damage = DMGCAP;
            }
            else if (damage < 1)
            {
                damage = 1;
                if (!(Defense.Unit.HP <= damage))
                {
                    flinched = true;
                }
            }
            if (flinched)
            {
                System.Threading.Thread.Sleep(1000);
                Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT + writtenline);
                writtenline++;
                Console.ForegroundColor = ConsoleColor.DarkGray;
                Console.Write("Foe {0} barely flinched!", DefenseName);
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {
                System.Threading.Thread.Sleep(1000);
                Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT + writtenline);
                writtenline++;
                Console.Write("Foe {0} took {1} damage!", DefenseName, damage);
            }
            Defense.RemoveHP(damage);
            if (Defense.IsAlive)
            {
                System.Threading.Thread.Sleep(1000);
                Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT + writtenline);
                writtenline++;
                Console.Write("Foe {0} retaliates!", DefenseName);
                effectiveness = GetEffectiveness(Defense.Unit.Class.Type, Offense.Unit.Class.Type);
                CritChance = Defense.Unit.BaseCrit;
                Krit = 1;
                if (CriticalHit(CritChance))
                {
                    System.Threading.Thread.Sleep(1000);
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT + writtenline);
                    writtenline++;
                    Console.ForegroundColor = Players[Defense.Unit.Player].UnitColor;
                    Console.Write("CRITICAL HIT!!");
                    Console.ForegroundColor = ConsoleColor.White;
                    Krit = 2;
                }
                damage = (int)Math.Round(Defense.Attack * effectiveness * Krit * RETALIATE - Offense.Defense);
                flinched = false;
                if (damage > DMGCAP)
                {
                    damage = DMGCAP;
                }
                else if (damage < 1)
                {
                    damage = 1;
                    if (!(Offense.Unit.HP <= damage))
                    {
                        flinched = true;
                    }
                }
                if (flinched)
                {
                    System.Threading.Thread.Sleep(1000);
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT + writtenline);
                    writtenline++;
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.Write("{0} barely flinched!", OffenseName);
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    System.Threading.Thread.Sleep(1000);
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT + writtenline);
                    writtenline++;
                    Console.Write("{0} took {1} damage!", OffenseName, damage);
                }
                Offense.RemoveHP(damage);
                if (!Offense.IsAlive)
                {
                    System.Threading.Thread.Sleep(1000);
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT + writtenline);
                    writtenline++;
                    Console.ForegroundColor = Players[currentPlayer].RegionColor;
                    Console.Write("{0} was defeated!", OffenseName);
                    Defense.Unit.AddXP(OffenseClass);
                    CheckWin();
                }
            }
            else
            {
                System.Threading.Thread.Sleep(1000);
                Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT + writtenline);
                writtenline++;
                Console.ForegroundColor = Players[currentPlayer].UnitColor;
                Console.Write("Foe {0} was defeated!", DefenseName);
                Offense.Unit.AddXP(DefenseClass);
                CheckWin();
            }
            if (!Win)
            {
                Console.ReadKey(true);
            }
        }
        static float GetEffectiveness(CombatType Offense, CombatType Defense)
        {
            const float SUPER_EFFECTIVE = 1.3f, NOT_EFFECTIVE = 0.8f;
            float effectiveness;
            if (((int)Defense + 1) % (int)CombatType.NONE == (int)Offense)
            {
                effectiveness = SUPER_EFFECTIVE;
            }
            else if (((int)Offense + 1) % (int)CombatType.NONE == (int)Defense)
            {
                effectiveness = NOT_EFFECTIVE;
            }
            else
            {
                effectiveness = 1f;
            }
            return effectiveness;
        }
        static bool CriticalHit(int Chance)
        {
            return Chance > Template.Random(64);
        }

        static bool SpecialCombat(int X, int Y)
        {
            bool end = false;
            if (Map[X, Y].Unit.Class is RangedUnit)
            {
                end = RangedAttack(X, Y);
            }
            else if (Map[X, Y].Unit.Class is MagicUnit)
            {
                end = Fireball(X, Y);
            }
            return end;
        }
        static bool RangedAttack(int X, int Y)
        {
            const int BASEHEIGHT = MENUHEIGHT + 10, DMGCAP = 999;
            bool end = false, aim = true, target = false;
            int TargetX = X, TargetY = Y;
            while (aim)
            {
                PrintCursor(TargetX, TargetY);
                Interface.Clear(BASEHEIGHT);
                bool validTarget = (80 - (Math.Sqrt((X - TargetX) * (X - TargetX) + (Y - TargetY) * (Y - TargetY)) * 10)) >= 35 &&
                     Map[TargetX, TargetY].IsAlive && Map[TargetX, TargetY].Unit.Player != currentPlayer;
                int prevX = TargetX, prevY = TargetY;
                if (validTarget)
                {
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT);
                    Console.Write("Ennemy ");
                    Console.ForegroundColor = Players[Map[TargetX, TargetY].Unit.Player].UnitColor;
                    Console.Write(Map[TargetX, TargetY].Unit.Class.Name);
                }
                else if (Map[TargetX, TargetY].IsCity || Map[TargetX, TargetY].IsAlive && Map[TargetX, TargetY].Unit.Player == currentPlayer)
                {
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("Invalid Target.");
                }
                else if ((80 - (Math.Sqrt((X - TargetX) * (X - TargetX) + (Y - TargetY) * (Y - TargetY)) * 10)) < 35)
                {
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT);
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.Write("Out of range.");
                }
                else
                {
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT);
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.Write("No Target.");
                }
                Console.ResetColor();
                bool valid = false;
                while (!valid)
                {
                    ConsoleKeyInfo key = Console.ReadKey(true);
                    switch (key.Key)
                    {
                        case ConsoleKey.Enter:
                            aim = !validTarget;
                            valid = validTarget;
                            target = validTarget;
                            break;
                        case ConsoleKey.Escape:
                            aim = false;
                            valid = true;
                            break;
                        case ConsoleKey.UpArrow:
                            if (TargetY > 0)
                            {
                                --TargetY;
                                valid = true;
                            }
                            break;
                        case ConsoleKey.DownArrow:
                            if (TargetY < HEIGHT - 1)
                            {
                                ++TargetY;
                                valid = true;
                            }
                            break;
                        case ConsoleKey.LeftArrow:
                            if (TargetX > 0)
                            {
                                --TargetX;
                                valid = true;
                            }
                            break;
                        case ConsoleKey.RightArrow:
                            if (TargetX < WIDTH - 1)
                            {
                                ++TargetX;
                                valid = true;
                            }
                            break;
                        default:
                            break;
                    }
                }
                PrintMap(prevX, prevY);
            }
            if (target)
            {
                Interface.ClearLine(BASEHEIGHT);
                int writtenline = 1;
                Interface.Clear(BASEHEIGHT);
                Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT);
                Console.ForegroundColor = ConsoleColor.White;
                MapTile Offense = Map[X, Y];
                MapTile Defense = Map[TargetX, TargetY];
                string OffenseName = Offense.Unit.Class.Name;
                string DefenseName = Defense.Unit.Class.Name;
                UnitClass OffenseClass = Offense.Unit.Class;
                UnitClass DefenseClass = Defense.Unit.Class;
                Console.Write("{0} Attacks!", OffenseName);
                float effectiveness = GetEffectiveness(Offense.Unit.Class.Type, Defense.Unit.Class.Type);
                float rangePenality = (float)(80 - (Math.Sqrt((X - TargetX) * (X - TargetX) + (Y - TargetY) * (Y - TargetY)) * 10))/100f;
                int CritChance = (int)(Offense.Unit.BaseCrit * 1.5f);
                int Krit = 1;
                if (CriticalHit(CritChance))
                {
                    System.Threading.Thread.Sleep(1000);
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT + writtenline);
                    writtenline++;
                    Console.ForegroundColor = Players[currentPlayer].UnitColor;
                    Console.Write("CRITICAL HIT!!");
                    Console.ForegroundColor = ConsoleColor.White;
                    Krit = 2;
                }
                int damage = (int)Math.Round(Offense.Attack * effectiveness * Krit * rangePenality - Defense.Defense/2);
                bool flinched = false;
                if (damage > DMGCAP)
                {
                    damage = DMGCAP;
                }
                else if (damage < 1)
                {
                    damage = 1;
                    if (!(Defense.Unit.HP <= damage))
                    {
                        flinched = true;
                    }
                }
                if (flinched)
                {
                    System.Threading.Thread.Sleep(1000);
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT + writtenline);
                    writtenline++;
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.Write("Foe {0} barely flinched!", DefenseName);
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    System.Threading.Thread.Sleep(1000);
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT + writtenline);
                    writtenline++;
                    Console.Write("Foe {0} took {1} damage!", DefenseName, damage);
                }
                Defense.RemoveHP(damage);
                if (!Defense.IsAlive)
                {
                    System.Threading.Thread.Sleep(1000);
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT + writtenline);
                    writtenline++;
                    Console.ForegroundColor = Players[currentPlayer].UnitColor;
                    Console.Write("Foe {0} was defeated!", DefenseName);
                    Offense.Unit.AddXP(DefenseClass);
                    CheckWin();
                }
                if (!Win)
                {
                    Console.ReadKey(true);
                    if (!Defense.IsAlive)
                    {
                        PrintMap(TargetX, TargetY);
                    }
                }
                end = true;
            }
            return end;
        }
        static bool Fireball(int X, int Y)
        {
            const int BASEHEIGHT = MENUHEIGHT + 10, DMGCAP = 999;
            int magic = GetMagic(X, Y);
            string potential = "High";
            if (magic > 50)
            {
                magic = 50;
            }
            else if (magic <= 15)
            {
                potential = "Low";
            }
            else if (magic < 35)
            {
                potential = "Medium";
            }
            bool end = false, aim = true, target = false;
            Console.SetCursorPosition(Interface.MENUPOSX + 16, MENUHEIGHT + 7);
            Console.Write("(Power: {0})", potential);
            int TargetX = X, TargetY = Y;
            while (aim)
            {
                PrintCursor(TargetX, TargetY);
                Interface.Clear(BASEHEIGHT);
                bool validTarget = Math.Sqrt((X - TargetX) * (X - TargetX) + (Y - TargetY) * (Y - TargetY)) < 2.5 &&
                     Map[TargetX, TargetY].IsAlive && Map[TargetX, TargetY].Unit.Player != currentPlayer;
                int prevX = TargetX, prevY = TargetY;
                if (validTarget)
                {
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT);
                    Console.Write("Ennemy ");
                    Console.ForegroundColor = Players[Map[TargetX, TargetY].Unit.Player].UnitColor;
                    Console.Write(Map[TargetX, TargetY].Unit.Class.Name);
                }
                else if (Map[TargetX, TargetY].IsCity || Map[TargetX, TargetY].IsAlive && Map[TargetX, TargetY].Unit.Player == currentPlayer)
                {
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("Invalid Target.");
                }
                else if (Math.Sqrt((X - TargetX) * (X - TargetX) + (Y - TargetY) * (Y - TargetY)) > 2.5)
                {
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT);
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.Write("Out of range.");
                }
                else
                {
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT);
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.Write("No Target.");
                }
                Console.ResetColor();
                bool valid = false;
                while (!valid)
                {
                    ConsoleKeyInfo key = Console.ReadKey(true);
                    switch (key.Key)
                    {
                        case ConsoleKey.Enter:
                            aim = !validTarget;
                            valid = validTarget;
                            target = validTarget;
                            break;
                        case ConsoleKey.Escape:
                            aim = false;
                            valid = true;
                            break;
                        case ConsoleKey.UpArrow:
                            if (TargetY > 0)
                            {
                                --TargetY;
                                valid = true;
                            }
                            break;
                        case ConsoleKey.DownArrow:
                            if (TargetY < HEIGHT - 1)
                            {
                                ++TargetY;
                                valid = true;
                            }
                            break;
                        case ConsoleKey.LeftArrow:
                            if (TargetX > 0)
                            {
                                --TargetX;
                                valid = true;
                            }
                            break;
                        case ConsoleKey.RightArrow:
                            if (TargetX < WIDTH - 1)
                            {
                                ++TargetX;
                                valid = true;
                            }
                            break;
                        default:
                            break;
                    }
                }
                PrintMap(prevX, prevY);
            }
            if (target)
            {
                float power = 0.5f + magic * 0.02f;
                Interface.ClearLine(BASEHEIGHT);
                int writtenline = 1;
                Interface.Clear(BASEHEIGHT);
                Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT);
                Console.ForegroundColor = ConsoleColor.White;
                MapTile Offense = Map[X, Y];
                MapTile Defense = Map[TargetX, TargetY];
                string OffenseName = Offense.Unit.Class.Name;
                string DefenseName = Defense.Unit.Class.Name;
                UnitClass OffenseClass = Offense.Unit.Class;
                UnitClass DefenseClass = Defense.Unit.Class;
                Console.Write("{0} Attacks!", OffenseName);
                float effectiveness = GetEffectiveness(Offense.Unit.Class.Type, Defense.Unit.Class.Type);
                int CritChance = (int)(Offense.Unit.BaseCrit);
                int Krit = 1;
                if (CriticalHit(CritChance))
                {
                    System.Threading.Thread.Sleep(1000);
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT + writtenline);
                    writtenline++;
                    Console.ForegroundColor = Players[currentPlayer].UnitColor;
                    Console.Write("CRITICAL HIT!!");
                    Console.ForegroundColor = ConsoleColor.White;
                    Krit = 2;
                }
                int damage = (int)Math.Round(Offense.Attack * effectiveness * Krit * power - Defense.Defense / 2);
                bool flinched = false;
                if (damage > DMGCAP)
                {
                    damage = DMGCAP;
                }
                else if (damage < 1)
                {
                    damage = 1;
                    if (!(Defense.Unit.HP <= damage))
                    {
                        flinched = true;
                    }
                }
                if (flinched)
                {
                    System.Threading.Thread.Sleep(1000);
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT + writtenline);
                    writtenline++;
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.Write("Foe {0} barely flinched!", DefenseName);
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    System.Threading.Thread.Sleep(1000);
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT + writtenline);
                    writtenline++;
                    Console.Write("Foe {0} took {1} damage!", DefenseName, damage);
                }
                Defense.RemoveHP(damage);
                if (!Defense.IsAlive)
                {
                    System.Threading.Thread.Sleep(1000);
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, BASEHEIGHT + writtenline);
                    writtenline++;
                    Console.ForegroundColor = Players[currentPlayer].UnitColor;
                    Console.Write("Foe {0} was defeated!", DefenseName);
                    Offense.Unit.AddXP(DefenseClass);
                    CheckWin();
                }
                if (!Win)
                {
                    Console.ReadKey(true);
                    if (!Defense.IsAlive)
                    {
                        PrintMap(TargetX, TargetY);
                    }
                }
                end = true;
            }
            return end;
        }
        static int GetMagic(int X, int Y)
        {
            int magic = 0;
            for (int y = Y + 1; y >= Y - 1; y--)
            {
                for (int x = X - 1; x <= X + 1; x++)
                {
                    if (!(x < 0 || y < 0 || x >= WIDTH || y >= HEIGHT))
                    {
                        magic += Map[X,Y].Magic;
                    }
                }
            }
            return magic;
        }

        static void Create()
        {
            Interface.Clear();
            Console.SetCursorPosition(Interface.MENUPOSX + 5, MENUHEIGHT);
            Console.Write("Create Unit");
            bool end = false;
            while (!end)
            {
                Interface.ClearLine(4,6);
                Interface.Clear(MENUHEIGHT + 1);
                PrintRessouces();
                List<string> cities = new List<string>();
                List<int[]> positions = new List<int[]>();
                for (int y = 0; y < HEIGHT; y++)
                {
                    for (int x = 0; x < WIDTH; x++)
                    {
                        if (Map[x, y].IsCity && Map[x, y].Unit.Player == currentPlayer && Map[x, y].Unit.Movement > 0)
                        {
                            cities.Add(Regions[Map[x, y].Region].Name);
                            positions.Add(new int[2] { x, y });
                        }
                    }
                }
                if (cities.Count != 0)
                {
                    string[] choices = cities.ToArray<string>();
                    int[][] pos = positions.ToArray<int[]>();
                    int[] choice = CursorMenu(choices, pos, MENUHEIGHT + 2);
                    if (choice[0] < 0)
                    {
                        end = true;
                    }
                    else
                    {
                        UnitClassSelect(choice[0], choice[1]);
                    }
                }
                else
                {
                    end = true;
                    Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 2);
                    Console.Write("No Suitable City.");
                    Console.ReadKey(true);
                }
            }
        }
        static void UnitClassSelect(int X, int Y)
        {
            Interface.Clear(MENUHEIGHT + 1);
            List<string> u = new List<string>(),
                         d = new List<string>();
            List<int> ind = new List<int>();
            for (int i = 0; i < Template.UNITS; i++)
            {
                if ((Template.Units(i)[0] + Template.Units(i)[1] + Template.Units(i)[2] > 0) && Players[currentPlayer].GetAvailiable(0) >= Template.Units(i)[0] && Players[currentPlayer].GetAvailiable(1) >= Template.Units(i)[1] && Players[currentPlayer].GetAvailiable(2) >= Template.Units(i)[2])
                {
                    u.Add(String.Format("{0} [{1},{2},{3}]", Template.Units(i).Name.PadRight(12), Template.Units(i)[0].ToString().PadLeft(2), Template.Units(i)[1].ToString().PadLeft(2), Template.Units(i)[2].ToString().PadLeft(2)));
                    d.Add(String.Format("HP:{0} Atk:{1} Def:{2} Movement:{3}", Template.Units(i).MaxHP.ToString().PadRight(3), Template.Units(i).Attack.ToString().PadRight(3), Template.Units(i).Defense.ToString().PadRight(3), Template.Units(i).Movement));
                    ind.Add(i);
                }
            }
            if (u.Count != 0)
            {
                string[] units = u.ToArray<string>();
                string[] desc = d.ToArray<string>();
                int[] index = ind.ToArray<int>();
                int result = Interface.Menu(units, desc, MENUHEIGHT + 2);
                if (result >= 0)
                {
                    BuildUnit(X, Y, Template.Units(index[result]));
                }
            }
            else
            {
                Console.SetCursorPosition(Interface.MENUPOSX + 1, MENUHEIGHT + 2);
                Console.Write("No Availiable Unit.");
                Console.ReadKey(true);
            }
        }
        static void BuildUnit(int X, int Y, UnitClass unit)
        {
            Interface.Clear(MENUHEIGHT + 1);
            Interface.ClearLine(4, 6);
            Console.SetCursorPosition(Interface.MENUPOSX, MENUHEIGHT + 2);
            Console.Write("Creating {0}", unit.Name);
            int choice = MovementWheel(X, Y, true);
            if (choice > 0)
            {
                int dX, dY;
                GetDeltas(choice, out dX, out dY);
                Map[X, Y].Unit.ResetMovement();
                Players[currentPlayer].RemoveRessources(unit);
                Map[X + dX, Y + dY].AddUnit(new Unit(unit, currentPlayer));
                PrintMap(X + dX, Y + dY);
            }
        }

        static void Status()
        {

        }

        static bool Save()
        {
            Interface.Clear(MENUHEIGHT);
            Console.SetCursorPosition(WIDTH + 2, MENUHEIGHT + 2);
            Console.Write("Name:");
            bool cancel = false;
            string name = Interface.GetStringInput(ref cancel);
            if (!cancel)
            {
                System.IO.StreamWriter File = new System.IO.StreamWriter(@Interface.SAVEFOLDER + "//" + name + Interface.SAVEXT);
                StringBuilder World = new StringBuilder();
                StringBuilder Region = new StringBuilder();
                World.AppendLine(String.Format("{0},{1},{2}", name, Regions.Length, currentPlayer));
                for (int p = 1; p < Players.Length; p++)
                {
                    int active = 0;
                    if (Players[p].IsActive) { active = 1; }
                    World.AppendLine(String.Format("{0},{1},{2},{3},{4},{5}", p, Players[p].Name, active, Players[p].GetTotal(0), Players[p].GetTotal(1), Players[p].GetTotal(2)));
                }
                for (int y = 0; y < HEIGHT; y++)
                {
                    for (int x = 0; x < WIDTH; x++)
                    {
                        char tile = EncodeTerrain(Map[x, y].Tile);
                        if (Map[x, y].IsAlive)
                        {
                            int index = GetClassIndex(Map[x, y].Unit.Class);
                            World.AppendLine(String.Format("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10}", 
                                tile,
                                Map[x, y].Region,
                                Map[x, y].Magic,
                                Map[x,y].Unit.Player,
                                index,
                                Map[x,y].Unit.HP,
                                Map[x,y].Unit.HPBonus,
                                Map[x,y].Unit.AtkBonus,
                                Map[x,y].Unit.DefBonus,
                                Map[x,y].Unit.CritBonus,
                                Map[x,y].Unit.MovBonus));
                        }
                        else if (Map[x, y].IsCity)
                        {
                            World.AppendLine(String.Format("{0},{1},{2},{3}", 
                                tile, Map[x, y].Region, Map[x, y].Magic, Map[x,y].Unit.Player));
                        }
                        else
                        {
                            World.AppendLine(String.Format("{0},{1},{2}",
                                tile,Map[x,y].Region,Map[x,y].Magic));
                        }
                    }
                }
                for (int r = 1; r < Regions.Length; r++)
                {
                    World.AppendLine(String.Format("{0},{1},{2},{3},{4},{5}",r,Regions[r].Name, Regions[r][0],Regions[r][1],Regions[r][2],Regions[r].Player));
                }
                File.Write(World);
                File.Flush();
                File.Close();
                Interface.Clear(MENUHEIGHT);
                Console.SetCursorPosition(WIDTH + 2, MENUHEIGHT + 2);
                Console.Write("Map saved. Keep playing?");
                cancel = (Interface.Menu(new string[] { "Yes" }, MENUHEIGHT + 3, "No") == 0);
            }
            return cancel;
        }
        static char EncodeTerrain(Tile t)
        {
            char terrain = ' ';
            if (t == Template.Ocean)
            {
                terrain = 'O';
            }
            else if (t == Template.Reef)
            {
                terrain = 'R';
            }
            else if (t == Template.Swamp)
            {
                terrain = 'S';
            }
            else if (t == Template.Plains)
            {
                terrain = 'P';
            }
            else if (t == Template.Grassland)
            {
                terrain = 'G';
            }
            else if (t == Template.Forest)
            {
                terrain = 'F';
            }
            else if (t == Template.Hill)
            {
                terrain = 'H';
            }
            else if (t == Template.Mountain)
            {
                terrain = 'M';
            }
            else if (t == Template.Snow)
            {
                terrain = 'N';
            }
            else if (t == Template.Desert)
            {
                terrain = 'D';
            }
            return terrain;
        }
        static int GetClassIndex(UnitClass u)
        {
            int i;
            bool done = false;
            for (i = 0; i < Template.UNITS && !done; i++)
            {
                done = (Template.Units(i) == u);
            }
            return --i;
        }

        static void PrintMap()
        {
            for (int y = 0; y < HEIGHT; y++)
            {
                for (int x = 0; x < WIDTH; x++)
                {
                    PrintMap(x, y);
                }
            }
        }
        static void PrintMap(int region)
        {
            for (int y = 0; y < HEIGHT; y++)
            {
                for (int x = 0; x < WIDTH; x++)
                {
                    if (Map[x, y].Region == region)
                    {
                        PrintMap(x, y);
                    }
                }
            }
        }
        static void PrintMap(int X, int Y)
        {
            Console.ResetColor();
            Console.SetCursorPosition(X, Y);
            if (Map[X, Y].Region == 0)
            {
                Console.BackgroundColor = ConsoleColor.Blue;
                Console.ForegroundColor = ConsoleColor.Black;
            }
            else
            {
                Console.BackgroundColor = Players[Regions[Map[X, Y].Region].Player].RegionColor;
            }
            if (Map[X, Y].IsAlive || Map[X, Y].IsCity)
            {
                Console.ForegroundColor = Players[Map[X,Y].Unit.Player].UnitColor;
                if (Map[X, Y].IsAlive && Map[X, Y].Unit.IsFortified)
                {
                    ConsoleColor temp = Console.ForegroundColor;
                    Console.ForegroundColor = Console.BackgroundColor;
                    Console.BackgroundColor = temp;
                }
            }
            Console.Write(Map[X, Y].Symbol);
            Console.ResetColor();
        }
        static void PrintCursor(int X, int Y)
        {
            Console.SetCursorPosition(X, Y);
            Console.ForegroundColor = Players[currentPlayer].UnitColor;
            Console.Write("X");
            Console.ResetColor();
        }
        static void PrintRessouces()
        {
            Console.SetCursorPosition(Interface.MENUPOSX, 4);
            Console.Write("Wood:  {0}/{1}", Players[currentPlayer].GetAvailiable(0).ToString().PadLeft(3), Players[currentPlayer].GetTotal(0));
            Console.SetCursorPosition(Interface.MENUPOSX, 5);
            Console.Write("Metal: {0}/{1}", Players[currentPlayer].GetAvailiable(1).ToString().PadLeft(3), Players[currentPlayer].GetTotal(1));
            Console.SetCursorPosition(Interface.MENUPOSX, 6);
            Console.Write("Magic: {0}/{1}", Players[currentPlayer].GetAvailiable(2).ToString().PadLeft(3), Players[currentPlayer].GetTotal(2));
        }
        public static int[] CursorMenu(string[] choices, int[][] pos, int posY)
        {
            string exit = "Cancel";
            int choice = 0;
            bool end = false;
            while (!end)
            {
                Interface.Clear(posY);
                if (choice != choices.Length)
                {
                    PrintCursor(pos[choice][0], pos[choice][1]);
                }
                Interface.PrintMenu(choices, posY, choice, exit);
                bool valid = false;
                while (!valid)
                {
                    ConsoleKeyInfo key = Console.ReadKey(true);
                    switch (key.Key)
                    {
                        case ConsoleKey.Enter:
                            if (choice != choices.Length)
                            {
                                PrintMap(pos[choice][0], pos[choice][1]);
                            }
                            valid = true;
                            end = true;
                            break;
                        case ConsoleKey.Escape: 
                            if (choice != choices.Length)
                            {
                                PrintMap(pos[choice][0], pos[choice][1]);
                            }
                            choice = choices.Length;
                            goto case ConsoleKey.Enter;
                        case ConsoleKey.UpArrow:
                            if (choice > 0)
                            {
                                if (choice != choices.Length)
                                {
                                    PrintMap(pos[choice][0], pos[choice][1]);
                                }
                                choice--;
                                valid = true;
                            }
                            break;
                        case ConsoleKey.DownArrow:
                            if (choice < choices.Length)
                            {
                                if (choice != choices.Length)
                                {
                                    PrintMap(pos[choice][0], pos[choice][1]);
                                }
                                choice++;
                                valid = true;
                            }
                            break;
                        case ConsoleKey.PageUp:
                            choice = 0;
                            valid = true;
                            break;
                        case ConsoleKey.PageDown:
                            choice = choices.Length;
                            valid = true;
                            break;
                    }
                }
            }
            int[] result = new int[2];
            if (choice == choices.Length)
            {
                result[0] = -1;
                result[1] = -1;
            }
            else
            {
                result[0] = pos[choice][0];
                result[1] = pos[choice][1];
            }
            return result;
        }
    }

    static class Template
    {
        public const int UNITS = 12;
        static Random Gen { get; set; }
        static UnitClass[] UnitList { get; set; }
        static public UnitClass Units(int i) { return UnitList[i]; }
        static public UnitClass Ent { get; private set; }
        static public Region Sea { get; private set; }
        static public UnitClass City { get; private set; }
        static public Tile Ocean { get; private set; }
        static public Tile Reef { get; private set; }
        static public Tile Swamp { get; private set; }
        static public Tile Plains { get; private set; }
        static public Tile Grassland { get; private set; }
        static public Tile Forest { get; private set; }
        static public Tile Hill { get; private set; }
        static public Tile Mountain { get; private set; }
        static public Tile Desert { get; private set; }
        static public Tile Snow { get; private set; }

        static Template()
        {
            Gen = new Random();
            Sea = new Region("Sea", new int[3] { 0, 0, 0 });
            InitializeTileList();
            InitializeUnitList();
        }
        static void InitializeTileList()
        {
            Ocean = new Tile('▒', "Ocean", 0.5f, 0.4f);
            Reef = new Tile('▓', "Reef", -1f, 0f);
            Swamp = new Tile('▬', "Swamp", 1.1f, 0.8f);
            Plains = new Tile('.', "Plains", 0.8f, 0.9f);
            Grassland = new Tile(';', "Grassland", 1f, 1f);
            Forest = new Tile('♣', "Forest", 1.5f, 1.3f);
            Hill = new Tile('⌂', "Hill", 2f, 1.5f);
            Mountain = new Tile('▲', "Mountain", -1f, 0f);
            Desert = new Tile('=', "Desert", 0.7f, 0.8f);
            Snow = new Tile('*', "Snow", 1.1f, 1.1f);
        }
        static void InitializeUnitList()
        {
            City = new City();
            UnitList = new UnitClass[UNITS];
            UnitList[0] = new UnitClass("Goblin", 'g',       12,  5, 1, 2, CombatType.MELEE, new int[] { 1, 1, 0 }, 4);
            UnitList[1] = new UnitClass("Scout", 's',        11,  4, 1, 4, CombatType.RANGED, new int[] { 1, 0, 0 });
            UnitList[2] = new UnitClass("Apprentice", 'â',    9,  6, 1, 2, CombatType.MAGIC, new int[] { 0, 0, 1 }, 3);
            UnitList[3] = new UnitClass("Swordsman", 'S',    22,  8, 4, 2, CombatType.MELEE, new int[] { 0, 3, 0 });
            UnitList[4] = new RangedUnit("Archer", 'A',      19,  8, 3, 3, CombatType.RANGED, new int[] { 3, 0, 0 });
            UnitList[5] = new MagicUnit("Mage", 'M',         17, 10, 3, 2, CombatType.MAGIC, new int[] { 0, 0, 3 });
            UnitList[6] = new UnitClass("Brute", 'B',        33, 16, 8, 2, CombatType.MELEE, new int[] { 1, 9, 0 }, 5);
            UnitList[7] = new UnitClass("Elf Tracker", 'È',  28, 16, 7, 4, CombatType.RANGED, new int[] { 9, 1, 0 }, 3);
            UnitList[8] = new UnitClass("Adept", 'å',        26, 19, 8, 2, CombatType.MAGIC, new int[] { 0, 0, 10 });
            UnitList[9] = new UnitClass("Monk", '┼',         24, 11, 6, 3, CombatType.RANGED, new int[] { 4, 0, 8 });
            UnitList[10] = new UnitClass("Druid", 'd',       24, 11, 6, 2, CombatType.MAGIC, new int[] { 8, 0, 4 });
            UnitList[11] = new Tree("Ent", 'Y',              20, 20, 3, 1, CombatType.RANGED, new int[] { 0, 0, 0 }, 3);
        }

        static public int Random()
        {
            Random gen = new Random();
            return gen.Next(100);
        }
        static public int Random(int max)
        {
            return Gen.Next(max);
        }
        static public int Random(int min, int max)
        {
            return Gen.Next(min, max);
        }
    }

    public enum CombatType
    {
        MELEE, MAGIC, RANGED, NONE
    }

    abstract class SpecialUnit : UnitClass
    {
        public abstract string Special { get;}

        protected SpecialUnit(string name, char sym, int hp, int atk, int def, int mov, CombatType type, int[] cost, int crit = 2)
            :base(name, sym, hp, atk, def, mov, type, cost, crit) {}
    }
    class UnitClass
    {
        int[] ressources = new int[3];
        public CombatType Type { get; private set; }
        public string Name { get; private set; }
        public char Symbol { get; private set; }
        public int MaxHP { get; private set; }
        public int Attack { get; private set; }
        public int Defense { get; private set; }
        public int Movement { get; private set; }
        public int BaseCrit { get; private set; }
        public int this[int resIndex]
        {
            get { return ressources[resIndex]; }
            private set { ressources[resIndex] = value; }
        }

        public UnitClass(string name, char sym, int hp, int atk, int def, int mov, CombatType type, int[] cost, int crit = 2)
        {
            Name = name;
            Symbol = sym;
            MaxHP = hp;
            Attack = atk;
            Defense = def;
            Movement = mov;
            Type = type;
            BaseCrit = crit;
            this[0] = cost[0];
            this[1] = cost[1];
            this[2] = cost[2];
        }
    }
    class City : UnitClass
    {
        public City()
            : base("City", '#', 1, 0, 0, 1, CombatType.NONE, new int[3] { 0, 0, 0 }) { }
    }
    class RangedUnit : SpecialUnit
    {
        public override string Special { get {return "Ranged Attack";} }

        public RangedUnit(string name, char sym, int hp, int atk, int def, int mov, CombatType type, int[] cost, int crit = 2)
            :base(name, sym, hp, atk, def, mov, type, cost, crit)
        { }
    }
    class MagicUnit : SpecialUnit
    {
        public override string Special { get { return "Magic Attack"; } }

        public MagicUnit(string name, char sym, int hp, int atk, int def, int mov, CombatType type, int[] cost, int crit = 2)
            : base(name, sym, hp, atk, def, mov, type, cost, crit)
        { }
    }
    class Tree : RangedUnit
    {
        public Tree(string name, char sym, int hp, int atk, int def, int mov, CombatType type, int[] cost, int crit = 2)
            :base(name, sym, hp, atk, def, mov, type, cost, crit)
        { }
    }

    class Unit
    {
        int hp;
        int hpBonus,
            atkBonus,
            defBonus,
            movBonus,
            critBonus;
        public UnitClass Class { get; private set; }
        public int Player { get; private set; }
        public int HP
        {
            get { return hp; }
            private set
            {
                hp = value;
                if (hp < 0)
                {
                    hp = 0;
                }
                else if (hp > MaxHP)
                {
                    hp = MaxHP;
                }
            }
        }
        public int AtkBonus
        {
            get { return atkBonus; }
            set
            {
                atkBonus = value;
                if (atkBonus > Class.Attack * Class.Attack * 3)
                {
                    atkBonus = Class.Attack * Class.Attack * 3;
                }
            }
        }
        public int DefBonus
        {
            get { return defBonus; }
            set
            {
                defBonus = value;
                if (defBonus > Class.Defense * Class.Defense * 3)
                {
                    defBonus = Class.Defense * Class.Defense * 3;
                }
            }
        }
        public int HPBonus
        {
            get { return hpBonus; }
            set
            {
                hpBonus = value;
                if (hpBonus > Class.MaxHP * Class.MaxHP * 4)
                {
                    hpBonus = Class.MaxHP * Class.MaxHP * 4;
                }
            }
        }
        public int MovBonus
        {
            get { return movBonus; }
            set
            {
                movBonus = value;
                if (movBonus > 100)
                {
                    movBonus = 100;
                }
            }
        }
        public int CritBonus
        {
            get { return critBonus; }
            set
            {
                critBonus = value;
                if (critBonus > 160)
                {
                    critBonus = 160;
                }
            }
        }
        public bool IsFortified { get; private set; }
        public int Attack { get { return Class.Attack + AtkBonus / (Class.Attack*10); } }
        public int Defense { get { return Class.Defense + DefBonus / (Class.Defense * 10); } }
        public int MaxHP { get { return Class.MaxHP + HPBonus / (Class.MaxHP*10); } }
        public int BaseCrit { get { return Class.BaseCrit + CritBonus / 20; } }
        public float Movement { get; private set; }

        public Unit(UnitClass Uclass, int pN)
        {
            Class = Uclass;
            Player = pN;
            IsFortified = false;
            HPBonus = Template.Random(0, 13*Class.MaxHP);
            AtkBonus = Template.Random(0, 12*Class.Attack);
            DefBonus = Template.Random(0, 12*Class.Defense);
            MovBonus = Template.Random(12);
            CritBonus = Template.Random(25);
            HP = MaxHP;
            Movement = 0;
        }
        public Unit(UnitClass Uclass, int pN, int hp, int hb, int ab, int db, int kb, int mb)
        {
            Class = Uclass;
            Player = pN;
            HPBonus = hb;
            AtkBonus = ab;
            DefBonus = db;
            MovBonus = mb;
            CritBonus = kb;
            HP = hp;
        }

        public void RemoveHP(int damage)
        {
            HP -= damage;
        }
        public void SetMovement()
        {
            Movement = Class.Movement + (MovBonus / 10) / 10f;
        }
        public void RemoveMovement(float value)
        {
            Movement = (float)Math.Round(Movement - value, 2);
            if (Movement <= 0.15f)
            {
                Movement = 0;
            }
            Unfortify();
        }
        public void ResetMovement()
        {
            Movement = 0;
        }
        public void Fortify()
        {
            ResetMovement();
            IsFortified = true;
        }
        public void Unfortify()
        {
            IsFortified = false;
        }
        public void ChangeCityOwner(int player)
        {
            Player = player;
            Movement = 0;
        }
        public void AddXP(UnitClass unit)
        {
            AtkBonus += Template.Random(unit.Attack / 2, unit.Attack * 3);
            DefBonus += Template.Random(unit.Defense / 2, unit.Defense * 3);
            HPBonus += Template.Random(unit.MaxHP / 2, unit.MaxHP * 2);
            MovBonus += Template.Random(unit.Movement / 2, unit.Movement * 3);
            CritBonus += Template.Random(unit.BaseCrit / 2, unit.BaseCrit * 3);
        }
    }
    class Tile
    {
        public char Symbol { get; private set; }
        public string Name { get; private set; }
        public float MovementCost { get; private set; }
        public float CombatBonus { get; private set; }

        public Tile(char symbol, string name, float moveCost, float bonus)
        {
            Symbol = symbol;
            Name = name;
            MovementCost = moveCost;
            CombatBonus = bonus;
        }
    }
    class MapTile
    {
        public Tile Tile { get; private set; }
        public int Region { get; private set; }
        public Unit Unit { get; private set; }
        public int Magic { get; private set; }
        public bool IsAlive { get { return Unit != null && !(Unit.Class is City); } }
        public bool IsCity { get { return Unit != null && Unit.Class is City; } }
        public char Symbol
        {
            get
            {
                char s;
                if (Unit == null)
                {
                    s = Tile.Symbol;
                }
                else
                {
                    s = Unit.Class.Symbol;
                }
                return s;
            }
        }
        public float Attack
        {
            get
            {
                if (IsAlive)
                {
                    return Unit.Attack * Tile.CombatBonus * (0.5f + Unit.HP/(float)Unit.MaxHP) * (Template.Random(90,111)/100f);
                }
                else
                {
                    return 0;
                }
            }
        }
        public float Defense
        {
            get 
            {
                if (IsAlive)
                {
                    float F = 1f;
                    if (Unit.IsFortified)
                    {
                        F = 1.5f;
                    }
                    return Unit.Defense * F * Tile.CombatBonus;
                }
                else
                {
                    return 0;
                }
            }
        }

        public MapTile(Tile t, int r, int m, Unit u = null)
        {
            Tile = t;
            Region = r;
            Unit = u;
            Magic = m;
        }

        public void RemoveHP(int damage)
        {
            if (IsAlive)
            {
                Unit.RemoveHP(damage);
                if (Unit.HP <= 0)
                {
                    KillUnit();
                }
            }
        }

        public void AddUnit(Unit newUnit)
        {
            Unit = newUnit;
        }
        public void KillUnit()
        {
            Unit = null;
        }
    }
    class PlayerInfo
    {
        public int Number { get; private set; }
        public string Name { get; private set; }
        public ConsoleColor UnitColor { get; private set; }
        public ConsoleColor RegionColor { get; private set; }
        public bool IsActive { get; private set; }
        int[] Total { get; set; }
        int[] Availiable { get; set; }
        public int GetTotal(int resIndex)
        {
            return Total[resIndex];
        }
        public int GetAvailiable(int resIndex)
        {
            return Availiable[resIndex];
        }

        public PlayerInfo(int pN, ConsoleColor unit, ConsoleColor region)
        {
            Number = pN;
            UnitColor = unit;
            RegionColor = region;
            Total = new int[3] { 0, 0, 0 };
            Availiable = new int[3] { 0, 0, 0 };
            IsActive = false;
        }

        public void Activate(string name, int w = 1, int m = 1, int M = 1)
        {
            IsActive = true;
            Name = name;
            Availiable[0] = w;
            Availiable[1] = m;
            Availiable[2] = M;
        }
        public void Deactivate()
        {
            IsActive = false;
        }
        public void UpdateRessources(int[] total, int[] avail)
        {
            Total = total;
            Availiable = avail;
        }
        public void RemoveRessources(UnitClass unit)
        {
            Availiable[0] -= unit[0];
            Availiable[1] -= unit[1];
            Availiable[2] -= unit[2];
        }
    }

    class Region
    {
        int[] ressources = new int[3];
        public string Name { get; private set; }
        public int Player { get; private set; }
        public int this[int resIndex]
        {
            get { return ressources[resIndex]; }
            private set { ressources[resIndex] = value; }
        }

        public Region(string name, int[] res)
        {
            Player = 0;
            Name = name;
            this[0] = res[0];
            this[1] = res[1];
            this[2] = res[2];
        }

        public void ChangePlayer(int player)
        {
            Player = player;
        }
    }
}
