﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Continental_Conquest
{
    class Program
    {
        public const int WIDTH = Interface.WIDTH, HEIGHT = Interface.HEIGHT;
        static void Main(string[] args)
        {
            System.IO.Directory.CreateDirectory(@Interface.MAPFOLDER);
            System.IO.Directory.CreateDirectory(@Interface.SAVEFOLDER);
            Console.SetWindowSize(100, HEIGHT);
            Interface.Display();
            bool play = true;
            string[] options = new string[3];
            options[0] = "New Game";
            options[1] = "Load Game";
            options[2] = "World Generator";
            while (play)
            {
                Interface.Clear();
                Interface.ClearLine(1);
                Interface.WriteTitle("Main Menu");
                switch (Interface.Menu(options, 8, "Exit"))
                {
                    case 0:
                        Game.Run();
                        break;
                    case 1:
                        Game.Load();
                        break;
                    case 2:
                        Generator.Run();
                        break;
                    case -1:
                        play = false;
                        break;
                    case -2:
                        goto case -1;
                }
            }
            Console.Clear();
        }
    }

    static class Interface
    {
        public const int WIDTH = 64,
                         HEIGHT = 52,
                         MENUPOSX = 65,
                         INPUTLIMIT = 20;
        public const string MAPFOLDER = "Maps",
                            SAVEFOLDER = "Saves",
                            MAPEXT = ".wrl",
                            SAVEXT = ".svg";
        public static int Menu(string[] choices, int posY, string exit = "Cancel")
        {
            int choice = 0;
            bool end = false;
            while (!end)
            {
                Clear(posY);
                PrintMenu(choices, posY, choice, exit);
                bool valid = false;
                while (!valid)
                {
                    ConsoleKeyInfo key = Console.ReadKey(true);
                    switch (key.Key)
                    {
                        case ConsoleKey.Enter:
                            valid = true;
                            end = true;
                            break;
                        case ConsoleKey.Escape:
                            choice = -2;
                            goto case ConsoleKey.Enter;
                        case ConsoleKey.UpArrow:
                            if (choice > 0)
                            {
                                choice--;
                                valid = true;
                            }
                            break;
                        case ConsoleKey.DownArrow:
                            if (choice < choices.Length)
                            {
                                choice++;
                                valid = true;
                            }
                            break;
                        case ConsoleKey.PageUp:
                            choice = 0;
                            valid = true;
                            break;
                        case  ConsoleKey.PageDown:
                            choice = choices.Length;
                            valid = true;
                            break;
                    }
                }
            }
            if (choice == choices.Length) { choice = -1; }
            return choice;
        }
        public static int Menu(string[] choices, string[] desc, int posY)
        {
            int choice = 0;
            bool end = false;
            while (!end)
            {
                Clear(posY);
                PrintMenu(choices, posY, choice, "Cancel");
                if (choice != choices.Length)
                {
                    Console.SetCursorPosition(MENUPOSX, posY + 8);
                    Console.Write(desc[choice]);
                }
                bool valid = false;
                while (!valid)
                {
                    ConsoleKeyInfo key = Console.ReadKey(true);
                    switch (key.Key)
                    {
                        case ConsoleKey.Enter:
                            valid = true;
                            end = true;
                            break;
                        case ConsoleKey.Escape:
                            choice = -1;
                            goto case ConsoleKey.Enter;
                        case ConsoleKey.UpArrow:
                            if (choice > 0)
                            {
                                choice--;
                                valid = true;
                            }
                            break;
                        case ConsoleKey.DownArrow:
                            if (choice < choices.Length)
                            {
                                choice++;
                                valid = true;
                            }
                            break;
                        case ConsoleKey.PageUp:
                            choice = 0;
                            valid = true;
                            break;
                        case ConsoleKey.PageDown:
                            choice = choices.Length;
                            valid = true;
                            break;
                    }
                }
            }
            if (choice == choices.Length)
            {
                choice = -1;
            }
            return choice;
        }
        public static void PrintMenu(string[] choices, int posY, int choice, string exit)

        {
            int y = 0;
            for (int i = choice - 3; i < choice + 4; i++, y++)
            {
                Console.SetCursorPosition(MENUPOSX, posY + y);
                if (i == choice)
                {
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write(">");
                }
                else
                {
                    Console.Write(" ");
                }
                if (i >= 0 && i < choices.Length)
                {
                    Console.Write(choices[i]);
                }
                else if (i == choices.Length)
                {
                    Console.Write(exit);
                }
                Console.ResetColor();
            }
        }

        public static void Clear(int PosY = 3)
        {
            for (; PosY < HEIGHT; PosY++)
            {
                ClearLine(PosY);
            }
        }
        public static void ClearLine(int PosY)
        {
            Console.SetCursorPosition(MENUPOSX, PosY);
            Console.Write("                                  ");
        }
        public static void ClearLine(int Start, int Finish)
        {
            if (Start <= Finish)
            {
                for (int i = Start; i <= Finish; i++)
                {
                    ClearLine(i);
                }
            }
            else
            {
                for (int i = Start; i >= Finish; i--)
                {
                    ClearLine(i);
                }
            }
        }

        public static void Display()
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            for (int i = 0; i < HEIGHT; i++)
            {
                Console.SetCursorPosition(WIDTH, i);
                Console.Write("║");
            }
            Console.SetCursorPosition(WIDTH, 2);
            Console.Write("©═══════════════════════════════════");
            Console.ResetColor();
        }
        public static void ClearMap()
        {
            for (int i = 0; i < HEIGHT; i++)
            {
                Console.SetCursorPosition(0, i);
                Console.Write("                                                                ");
            }
        }

        public static string GetStringInput(ref bool cancel)
        {
            string result = string.Empty;
            bool end = false;
            while (!end)
            {
                ConsoleKeyInfo key = Console.ReadKey(true);
                switch (key.Key)
                {
                    case ConsoleKey.Enter:
                        if (result != "")
                        {
                            end = true;
                        }
                        else
                        {
                            cancel = true;
                            end = true;
                        }
                        break;
                    case ConsoleKey.Escape:
                        cancel = true;
                        end = true;
                        break;
                    default:
                        char c = key.KeyChar;
                        if (c == '\b' && result != "")
                        {
                            result = result.Substring(0, result.Length - 1);
                            Console.Write("\b \b");
                        }
                        else if (result.Length < INPUTLIMIT && char.IsLetterOrDigit(c))
                        {
                            result += c;
                            Console.Write(c);
                        }
                        break;
                }
            }
            return result;
        }

        internal static void WriteTitle(string title)
        {
            ClearLine(1);
            Console.SetCursorPosition(MENUPOSX, 1);
            Console.Write(title);
        }
    }
}

