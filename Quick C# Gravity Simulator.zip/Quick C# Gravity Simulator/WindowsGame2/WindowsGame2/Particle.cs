using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


namespace WindowsGame2
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    /// 

    public class Particle : Microsoft.Xna.Framework.DrawableGameComponent
    {
        SpriteBatch GestionSprites { get; set; }

        Color color;
        int mass;
        Vector2 speed;
        Vector2 position;
        Rectangle DrawBox;
        Texture2D Atom;

        public Color ParticleColor 
        { get { return color; } 
            set 
            {
                if (value == Color.White || value == Color.Yellow || value == Color.Magenta ||
                    value == Color.Red || value == Color.Blue || value == Color.Cyan || value == Color.Green)
                {
                    color = value;
                }
            } 
        }
        public int Mass 
        { 
            get { return mass; } 
            set 
            {
                if (value > 0 && value < int.MaxValue) { mass = value; }
            } 
        }
        public Vector2 Speed 
        { 
            get { return speed; } 
            set 
            {
                if (!float.IsNaN(value.X) && !float.IsNaN(value.Y))
                    speed = value;
            } 
        }
        public Vector2 Position
        {
            get { return position; }
            set
            {
                if (!float.IsNaN(value.X) && !float.IsNaN(value.Y))
                    position = value;
            }
        }

        public float Radius() { return 5 * (float)Math.Pow(Mass / Math.PI, (1f/2f)); }

        public Particle(Game game, Color c, int m, Vector2 pos, Vector2 speed)
            : base(game)
        {
            ParticleColor = c;
            Mass = m;
            Position = pos;
            Speed = speed;
            DrawBox = new Rectangle(0, 0, 1, 1);
        }

        /// <summary>
        /// Allows the game component to perform any initialization it needs to before starting
        /// to run.  This is where it can query for any required services and load content.
        /// </summary>
        public override void Initialize()
        {
            // TODO: Add your initialization code here
            GestionSprites = Game.Services.GetService(typeof(SpriteBatch)) as SpriteBatch;
            Atom = Game.Services.GetService(typeof(Texture2D)) as Texture2D;
            base.Initialize();
        }


        /// <summary>
        /// Allows the game component to update itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Update(GameTime gameTime)
        {
            Position += Speed;
            
            CheckBounds();
            DrawBox = new Rectangle((int)(Position.X - Radius()),(int)(Position.Y - Radius()),(int)(2 * Radius()),(int)((int)(2 * Radius())));
            base.Update(gameTime);
        }

        void CheckBounds()
        {
            if (Position.X - Radius() < 0)
            {
                Position = new Vector2((int)Radius() + 1, Position.Y);
                Bounce(new Vector2(1, 0));
            }
            else if (Position.X + Radius() > Game.Window.ClientBounds.Width)
            {
                Position = new Vector2(Game.Window.ClientBounds.Width - (int)Radius() - 1, Position.Y);
                Bounce(new Vector2(-1, 0));
            }
            if (Position.Y - Radius() < 0)
            {
                Position = new Vector2(Position.X, (int)Radius() + 1);
                Bounce(new Vector2(0, 1));
            }
            else if (Position.Y + Radius() > Game.Window.ClientBounds.Height)
            {
                Position = new Vector2(Position.X, Game.Window.ClientBounds.Height - (int)Radius() - 1);
                Bounce(new Vector2(0, -1));
            }
        }
        public void Bounce(Vector2 Normal)
        {
            Normal.Normalize();
            Vector2 s = Speed;
            Vector2.Reflect(ref s, ref Normal, out s);
            Speed = s;
        }

        public override void Draw(GameTime gameTime)
        {
            GestionSprites.Draw(Atom, DrawBox, color);
            base.Draw(gameTime);
        }
    }
}
