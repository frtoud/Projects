using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace WindowsGame2
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        private float TempsDepuisMAJ;
        List<Particle> Particles;
        public Texture2D Atom { get; private set; }
        Random random;

        public Game1()
        {

            graphics = new GraphicsDeviceManager(this);
            
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            random = new Random();
            graphics.PreferredBackBufferHeight = 800;
            graphics.PreferredBackBufferWidth = 1200;
            graphics.ApplyChanges();
            Particles = new List<Particle>(32);
            Atom = Content.Load<Texture2D>("Atom");
            spriteBatch = new SpriteBatch(GraphicsDevice);
            Services.AddService(typeof(SpriteBatch), spriteBatch);
            Services.AddService(typeof(Texture2D), Atom);
            foreach (Particle p in Particles)
            {
                p.Initialize();
            }
            // TODO: Add your initialization logic here
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures
            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            Content.Unload();
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (Keyboard.GetState().IsKeyDown(Keys.Escape))
                this.Exit();
            float Temps�coul� = (float)gameTime.ElapsedGameTime.TotalSeconds;
            TempsDepuisMAJ += Temps�coul�;
            if (TempsDepuisMAJ >= 0.02)
            {
                TempsDepuisMAJ = 0;




                for (int i = 0; i < Particles.Count; i++)
                {
                    if (Particles[i] != null)
                    {
                        for (int j = i + 1; j < Particles.Count; j++)
                        {
                            if (Particles[j] != null)
                            {
                                
                                CheckPhysics(Particles[i], Particles[j]);
                                CheckCollision(Particles[i], Particles[j]);
                                
                                
                            }
                        }
                    }
                }
                foreach (Particle p in Particles)
                {
                    p.Update(gameTime);
                }
            }
            Particles.RemoveAll(item => item == null);
            
                if (Particles.Count < 5)
                {
                    Color c = Color.White;
                    switch (random.Next(0,3))
                    {
                        case 0:
                            c = Color.Red;
                            break;
                        case 1:
                            c = Color.Blue;
                            break;
                        case 2:
                            c = Color.Green;
                            break;
                    }
                    c = Color.Green;
                    Particle p = new Particle(this, c, random.Next(20, 50),
                        new Vector2(random.Next(250, Window.ClientBounds.Width - 250),
                            random.Next(250, Window.ClientBounds.Height - 250)),
                        new Vector2((float)random.NextDouble()*5 - 1.5f, (float)random.NextDouble()*5 - 2.5f));
                    p.Initialize();
                    Particles.Add(p);

                }
            base.Update(gameTime);

        }

        bool CheckCollision(Particle I, Particle J)
        {
            bool r = false;
            if ((I.Position - J.Position).Length() < I.Radius() + J.Radius())
            {
                r = true;
                if (I.ParticleColor == J.ParticleColor)
                {
                    Vector2 BounceVector = (I.Position - J.Position);
                    float overlap = I.Radius() + J.Radius() - BounceVector.Length();
                    BounceVector.Normalize();
                    J.Position -= BounceVector * (overlap / 2 + 1);
                    I.Position += BounceVector * (overlap / 2 + 1);

                    Vector2 CollisionSpeedI = BounceVector * Vector2.Dot(I.Speed, BounceVector);
                    Vector2 CollisionSpeedJ = BounceVector * Vector2.Dot(J.Speed, BounceVector);


                    float ExcessMoment = (I.Mass*CollisionSpeedI - J.Mass*CollisionSpeedJ).Length();

                    I.Speed += (ExcessMoment) * BounceVector / I.Mass;
                    J.Speed -= (ExcessMoment) * BounceVector / J.Mass;
                }
                else
                {
                    Color ResultColor = GetResultingColor(I.ParticleColor, J.ParticleColor);
                    if (ResultColor != Color.Black)
                    {
                        //I.ParticleColor = ResultColor;
                        if (r)
                        {
                            I.Speed = (I.Speed * I.Mass + J.Speed * J.Mass) / (I.Mass + J.Mass);
                            I.Position += (J.Position - I.Position) * (J.Mass) / (I.Mass);
                            I.Mass += J.Mass;
                            Particles.Remove(J);
                        }

                        else
                        {
                            I.Bounce(I.Position - J.Position);
                            J.Bounce(J.Position - I.Position);
                        }
                    }
                }
                
            }
            return r;
        }

        void CheckPhysics(Particle I, Particle J)
        {
            switch (ColorCode(I.ParticleColor))
            {
                case 1:
                    switch (ColorCode(J.ParticleColor))
                    {
                        case 1:
                        case 3:
                        case 5:
                        case 7:
                            Accelerate(I, J);
                            break;
                    }
                    break;
                case 2:
                    switch (ColorCode(J.ParticleColor))
                    {
                        case 2:
                        case 3:
                        case 6:
                        case 7:
                            Attract(I, J);
                            break;
                    }
                    break;
                case 3:
                    switch (ColorCode(J.ParticleColor))
                    {
                        case 1:
                            Accelerate(I, J);
                            break;
                        case 2:
                            Attract(I, J);
                            break;
                        case 3:
                        case 7:
                            Attract(I, J);
                            Accelerate(I, J);
                            break;
                    }
                    break;
                case 4:
                    switch (ColorCode(J.ParticleColor))
                    {
                        case 4:
                        case 5:
                        case 6:
                        case 7:
                            Revolve(I, J);
                            break;
                    }
                    break;
                case 5:
                    switch (ColorCode(J.ParticleColor))
                    {
                        case 1:
                            Accelerate(I, J);
                            break;
                        case 2:
                            Revolve(I, J);
                            break;
                        case 3:
                        case 7:
                            Revolve(I, J);
                            Accelerate(I, J);
                            break;
                    }
                    break;
                case 6:
                    switch (ColorCode(J.ParticleColor))
                    {
                        case 2:
                            Attract(I, J);
                            break;
                        case 4:
                            Revolve(I, J);
                            break;
                        case 6:
                        case 7:
                            Revolve(I, J);
                            Attract(I, J);
                            break;
                    }
                    break;
                case 7:
                    switch (ColorCode(J.ParticleColor))
                    {
                        case 1:
                            Accelerate(I, J);
                            break;
                        case 2:
                            Attract(I, J);
                            break;
                        case 3:
                            Accelerate(I, J);
                            Attract(I, J);
                            break;
                        case 4:
                            Revolve(I, J);
                            break;
                        case 5:
                            Revolve(I, J);
                            Accelerate(I, J);
                            break;
                        case 6:
                            Revolve(I, J);
                            Attract(I, J);
                            break;
                        case 7:
                            Accelerate(I, J);
                            Revolve(I, J);
                            Attract(I, J);
                            break;
                    }
                    break;
            }
        }

        void Attract(Particle I, Particle J)
        {
            
            Vector2 ForceVector = (I.Position - J.Position);
            
            float rSq = (ForceVector).LengthSquared();
            ForceVector.Normalize();
            
            I.Speed -= 5 * ForceVector * J.Mass / rSq;
            J.Speed += 5 * ForceVector * I.Mass / rSq;
            
        }
        void Revolve(Particle I, Particle J)
        {
            Vector2 ForceVector = (I.Position - J.Position);
            float rSq = (ForceVector).LengthSquared();
            ForceVector.Normalize();

        }
        void Accelerate(Particle I, Particle J)
        {

        }

        Color GetResultingColor(Color I, Color J)
        {
            Color x = Color.Black;
            switch (ColorCode(I))
            {
                case 1:
                    switch (ColorCode(J))
                    {
                        case 2:
                            x = Color.Yellow;
                            break;
                        case 4:
                            x = Color.Magenta;
                            break;
                        case 6:
                            x = Color.White;
                            break;
                    }
                    break;
                case 2:
                    switch (ColorCode(J))
                    {
                        case 1:
                            x = Color.Yellow;
                            break;
                        case 4:
                            x = Color.Cyan;
                            break;
                        case 5:
                            x = Color.White;
                            break;
                    }
                    break;
                case 3: 
                    switch (ColorCode(J))
                    {
                        case 4:
                            x = Color.White;
                            break;
                    }
                    break;
                case 4:
                    switch (ColorCode(J))
                    {
                        case 1:
                            x = Color.Magenta;
                            break;
                        case 2:
                            x = Color.Cyan;
                            break;
                        case 3:
                            x = Color.White;
                            break;
                    }
                    break;
                case 5:
                    switch (ColorCode(J))
                    {
                        case 2:
                            x = Color.White;
                            break;
                    }
                    break;
                case 6:
                    switch (ColorCode(J))
                    {
                        case 1:
                            x = Color.White;
                            break;
                    }
                    break;
            }
            return x;
        }
        int ColorCode(Color color)
        {
            int x = 0;
            if (color == Color.Red)
            {
                x = 1;
            }
            else if (color == Color.Green)
            {
                x = 2;
            }
            else if (color == Color.Yellow)
            {
                x = 3;
            }
            else if (color == Color.Blue)
            {
                x = 4;
            }
            else if (color == Color.Magenta)
            {
                x = 5;
            }
            else if (color == Color.Cyan)
            {
                x = 6;
            }
            else if (color == Color.White)
            {
                x = 7;
            }
            
            return x;
        }
        


        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.SlateGray);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
            foreach (Particle p in Particles)
            {
                p.Draw(gameTime);
            }
            base.Draw(gameTime);
            spriteBatch.End();
        }
    }
}
